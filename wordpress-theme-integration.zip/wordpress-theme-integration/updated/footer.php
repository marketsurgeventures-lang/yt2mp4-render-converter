<?php if (!defined('ABSPATH')) { exit; } ?>
<footer class="site-footer"><div class="wrap">
<div class="cols three">
<div><h2><?php echo esc_html(yt2_site_name()); ?></h2><p>Convert your authorized YouTube videos to MP4 or MP3. Independent project; not affiliated with YouTube or Google.</p></div>
<div><h2>Pages</h2><?php yt2_menu('footer_pages', 'nav'); ?></div>
<div><h2>Legal</h2><?php yt2_menu('footer_legal', 'legal'); ?></div>
</div>
<p class="fine">YouTube is a trademark of Google LLC. Only download and convert videos you own or have permission to use. &copy; <?php echo esc_html(gmdate('Y')); ?></p>
</div></footer>
<?php wp_footer(); ?>
</body>
</html>
