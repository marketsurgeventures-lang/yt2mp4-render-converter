<?php
/**
 * yt2mp4 theme.
 * - Pages and blog posts are normal WordPress content (edit them in the block editor).
 * - Menus: Appearance > Menus (Primary, Footer pages, Footer legal).
 * - SEO title / description / noindex: box under each page or post.
 * - Indexing: Settings > Reading > "Discourage search engines" (checked = whole site noindex, header + meta).
 * Starter content (the 8 pages) is created once, on first activation, from /content and /inc/pages.json.
 */
if (!defined('ABSPATH')) { exit; }

function yt2_data() {
    static $d = null;
    if ($d === null) { $d = json_decode(file_get_contents(get_template_directory() . '/inc/pages.json'), true); }
    return $d;
}
function yt2_indexable() { return get_option('blog_public') == '1'; }
function yt2_site_name() { return get_bloginfo('name'); }

add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('script', 'style', 'search-form', 'gallery', 'caption'));
    add_theme_support('responsive-embeds');
    add_theme_support('align-wide');
    register_nav_menus(array(
        'primary'      => 'Primary (header)',
        'footer_pages' => 'Footer: pages',
        'footer_legal' => 'Footer: legal',
    ));
    // Block content does not need auto-paragraphs; this keeps the HTML blocks exactly as written.
    remove_filter('the_content', 'wpautop');
    remove_filter('the_excerpt', 'wpautop');
});

add_filter('show_admin_bar', '__return_false');
add_filter('xmlrpc_enabled', '__return_false');
add_filter('excerpt_length', function () { return 28; });
add_filter('excerpt_more', function () { return '…'; });

add_action('init', function () {
    remove_action('wp_head', 'wp_generator');
    remove_action('wp_head', 'rsd_link');
    remove_action('wp_head', 'wlwmanifest_link');
    remove_action('wp_head', 'wp_shortlink_wp_head');
    remove_action('wp_head', 'rest_output_link_wp_head');
    remove_action('wp_head', 'wp_oembed_add_discovery_links');
    remove_action('wp_head', 'rel_canonical');
    remove_action('wp_head', 'wp_robots', 1);
    remove_action('wp_head', 'adjacent_posts_rel_link_wp_head', 10);
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('template_redirect', 'rest_output_link_header', 11);
    remove_action('template_redirect', 'wp_shortlink_header', 11);
});

add_action('wp_enqueue_scripts', function () {
    foreach (array('classic-theme-styles', 'global-styles') as $h) { wp_dequeue_style($h); }
    $css = get_template_directory() . '/assets/css/app.css';
    wp_enqueue_style('yt2mp4', get_template_directory_uri() . '/assets/css/app.css', array(), file_exists($css) ? filemtime($css) : null);
}, 100);
remove_action('wp_enqueue_scripts', 'wp_enqueue_global_styles');

add_filter('language_attributes', function ($out) {
    $d = yt2_data();
    return $out . ' data-max-mb="' . (int) $d['maxMb'] . '"';
});

/* ---------- SEO: per-page / per-post fields ---------- */
add_action('add_meta_boxes', function () {
    foreach (array('page', 'post') as $t) {
        add_meta_box('yt2_seo', 'Search appearance (yt2mp4)', 'yt2_seo_box', $t, 'normal', 'default');
    }
});
function yt2_seo_box($post) {
    wp_nonce_field('yt2_seo', 'yt2_seo_nonce');
    $t = get_post_meta($post->ID, '_yt2_title', true);
    $d = get_post_meta($post->ID, '_yt2_desc', true);
    $n = get_post_meta($post->ID, '_yt2_noindex', true);
    echo '<p><label for="yt2_title"><strong>SEO title</strong> (about 50 to 60 characters; leave empty to use the page title)</label><br><input type="text" id="yt2_title" name="yt2_title" value="' . esc_attr($t) . '" class="widefat"></p>';
    echo '<p><label for="yt2_desc"><strong>Meta description</strong> (about 140 to 160 characters; leave empty to use the excerpt)</label><br><textarea id="yt2_desc" name="yt2_desc" rows="3" class="widefat">' . esc_textarea($d) . '</textarea></p>';
    echo '<p><label><input type="checkbox" name="yt2_noindex" value="1"' . checked($n, '1', false) . '> Keep this page out of search results (noindex)</label></p>';
    echo '<p class="description">The whole site follows Settings &rarr; Reading &rarr; &ldquo;Discourage search engines&rdquo;. While that box is checked, every page is noindex regardless of this setting.</p>';
}
add_action('save_post', function ($id) {
    if (!isset($_POST['yt2_seo_nonce']) || !wp_verify_nonce($_POST['yt2_seo_nonce'], 'yt2_seo')) { return; }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) { return; }
    if (!current_user_can('edit_post', $id)) { return; }
    update_post_meta($id, '_yt2_title', sanitize_text_field(wp_unslash($_POST['yt2_title'] ?? '')));
    update_post_meta($id, '_yt2_desc', sanitize_textarea_field(wp_unslash($_POST['yt2_desc'] ?? '')));
    update_post_meta($id, '_yt2_noindex', empty($_POST['yt2_noindex']) ? '' : '1');
});

/* ---------- resolve metadata for the current request ---------- */
function yt2_meta() {
    static $m = null;
    if ($m !== null) { return $m; }
    $site = yt2_site_name();
    $m = array('title' => $site, 'desc' => '', 'url' => home_url('/'), 'type' => 'website', 'noindex' => false, 'jsonld' => '', 'canonical' => true);
    if (is_singular()) {
        $id = get_queried_object_id();
        $t = get_post_meta($id, '_yt2_title', true);
        $m['title'] = $t ? $t : (is_front_page() ? $site : get_the_title($id) . ' | ' . $site);
        $desc = get_post_meta($id, '_yt2_desc', true);
        if (!$desc) { $desc = wp_trim_words(wp_strip_all_tags(strip_shortcodes(get_post_field('post_content', $id))), 26, '…'); }
        $m['desc'] = $desc;
        $m['url'] = get_permalink($id);
        $m['type'] = is_single() ? 'article' : 'website';
        $m['noindex'] = get_post_meta($id, '_yt2_noindex', true) === '1';
        $ld = get_post_meta($id, '_yt2_jsonld', true);
        if (!$ld && is_single()) {
            $ld = wp_json_encode(array('@context' => 'https://schema.org', '@type' => 'Article', 'headline' => get_the_title($id), 'description' => $desc, 'mainEntityOfPage' => $m['url'], 'inLanguage' => 'en-US', 'datePublished' => get_the_date('c', $id), 'dateModified' => get_the_modified_date('c', $id), 'author' => array('@type' => 'Person', 'name' => get_the_author_meta('display_name', get_post_field('post_author', $id)))), JSON_UNESCAPED_SLASHES);
        }
        $m['jsonld'] = $ld;
        // The new homepage must describe the server converter, including its current limits.
        if (is_front_page() && has_shortcode((string)get_post_field('post_content', $id), 'render_video_converter')) {
            $m['title'] = 'YouTube to MP4 & MP3 Converter | yt2mp4';
            $m['desc'] = 'Convert authorized public YouTube videos to MP4 or MP3. Free pilot: up to 2 minutes, 360p video, and 20 MB per file.';
            $m['jsonld'] = '';
        }
    } elseif (is_404()) {
        $m['title'] = 'Page not found | ' . $site; $m['noindex'] = true; $m['canonical'] = false;
    } elseif (is_search()) {
        $m['title'] = 'Search | ' . $site; $m['noindex'] = true; $m['canonical'] = false;
    } elseif (is_home() || is_archive()) {
        $page_for_posts = (int) get_option('page_for_posts');
        if (is_home() && $page_for_posts) {
            $m['title'] = (get_post_meta($page_for_posts, '_yt2_title', true) ?: 'Blog | ' . $site);
            $m['desc'] = (get_post_meta($page_for_posts, '_yt2_desc', true) ?: 'Guides and notes about video formats, MP4 and converting video files.');
            $m['url'] = get_permalink($page_for_posts);
        } else {
            $m['title'] = wp_strip_all_tags(get_the_archive_title()) . ' | ' . $site;
            $m['desc'] = wp_strip_all_tags(get_the_archive_description());
            $m['url'] = (is_category() || is_tag() || is_tax()) ? get_term_link(get_queried_object()) : home_url('/');
        }
    }
    if (is_wp_error($m['url'])) { $m['url'] = home_url('/'); }
    return $m;
}

add_filter('pre_get_document_title', function () { $m = yt2_meta(); return $m['title']; });

add_action('wp_head', function () {
    $m = yt2_meta();
    $robots = !yt2_indexable() ? 'noindex,nofollow,noarchive' : ($m['noindex'] ? 'noindex,follow' : 'index,follow,max-snippet:-1,max-image-preview:large');
    $d = yt2_data();
    if ($m['desc']) { echo '<meta name="description" content="' . esc_attr($m['desc']) . '">' . "\n"; }
    echo '<meta name="robots" content="' . esc_attr($robots) . '">' . "\n";
    if ($m['canonical']) { echo '<link rel="canonical" href="' . esc_url($m['url']) . '">' . "\n"; }
    echo '<meta name="theme-color" content="' . esc_attr($d['themeColor']) . '">' . "\n";
    echo '<meta property="og:type" content="' . esc_attr($m['type']) . '">' . "\n";
    echo '<meta property="og:site_name" content="' . esc_attr(yt2_site_name()) . '">' . "\n";
    echo '<meta property="og:title" content="' . esc_attr($m['title']) . '">' . "\n";
    if ($m['desc']) { echo '<meta property="og:description" content="' . esc_attr($m['desc']) . '">' . "\n"; }
    echo '<meta property="og:url" content="' . esc_url($m['url']) . '">' . "\n";
    $img = get_template_directory_uri() . '/assets/img/og.png'; $w = 1200; $h = 630;
    if (is_singular() && has_post_thumbnail()) { $src = wp_get_attachment_image_src(get_post_thumbnail_id(), 'large'); if ($src) { $img = $src[0]; $w = $src[1]; $h = $src[2]; } }
    echo '<meta property="og:image" content="' . esc_url($img) . '">' . "\n";
    echo '<meta property="og:image:width" content="' . (int) $w . '"><meta property="og:image:height" content="' . (int) $h . '">' . "\n";
    echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
    echo '<link rel="icon" href="' . esc_url(get_template_directory_uri() . '/favicon.svg') . '" type="image/svg+xml">' . "\n";
    echo '<link rel="preload" href="' . esc_url(get_template_directory_uri() . '/assets/fonts/bricolage.woff2') . '" as="font" type="font/woff2" crossorigin>' . "\n";
    if (!empty($m['jsonld'])) { echo '<script type="application/ld+json">' . $m['jsonld'] . '</script>' . "\n"; }
}, 2);

/* ---------- headers (front end) ---------- */
add_action('send_headers', function () {
    if (is_admin()) { return; }
    header("Content-Security-Policy: default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https://i.ytimg.com https://secure.gravatar.com; media-src 'self' blob:; connect-src 'self' https://www.youtube.com https://yt2mp4-render-converter.onrender.com; worker-src 'self' blob:; font-src 'self'; frame-src https://www.youtube-nocookie.com https://www.youtube.com; frame-ancestors 'none'; base-uri 'self'; form-action 'self'; object-src 'none'");
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()');
    header('Strict-Transport-Security: max-age=31536000');
    if (!yt2_indexable()) { header('X-Robots-Tag: noindex, nofollow, noarchive'); }
});

add_action('template_redirect', function () {
    $d = yt2_data();
    $host = parse_url($d['origin'], PHP_URL_HOST);
    if (!empty($_SERVER['HTTP_HOST']) && stripos($_SERVER['HTTP_HOST'], 'www.') === 0 && strcasecmp(substr($_SERVER['HTTP_HOST'], 4), $host) === 0) {
        wp_redirect(home_url(add_query_arg(array())), 301);
        exit;
    }
}, 1);

/* ---------- converter script: loads on any page whose content contains the tool ---------- */
add_action('wp_footer', function () {
    if (is_singular() && strpos((string) get_post_field('post_content', get_queried_object_id()), 'id="tool"') !== false) {
        $yt2_js = get_template_directory() . '/assets/js/app.js'; echo '<script type="module" src="' . esc_url(get_template_directory_uri() . '/assets/js/app.js?ver=' . (file_exists($yt2_js) ? filemtime($yt2_js) : '1')) . '"></script>' . "\n";
    }
}, 20);

/* ---------- menus ---------- */
function yt2_menu($location, $fallback_key, $items_wrap = '<ul>%3$s</ul>') {
    if (has_nav_menu($location)) {
        wp_nav_menu(array('theme_location' => $location, 'container' => false, 'menu_class' => '', 'items_wrap' => $items_wrap, 'depth' => 1));
        return;
    }
    $d = yt2_data();
    echo '<ul>';
    foreach ($d[$fallback_key] as $n) { echo '<li><a href="' . esc_url($n['href']) . '">' . esc_html($n['label']) . '</a></li>'; }
    echo '</ul>';
}

/* ---------- first activation: starter content ---------- */
add_action('after_switch_theme', function () {
    $d = yt2_data();
    if (get_option('yt2_seeded')) { return; }
    $ids = array();
    foreach ($d['pages'] as $slug => $p) {
        $slug = (string) $slug; // PHP turns the numeric key '404' into an int
        if ($slug === '404') { continue; }
        $existing = get_page_by_path($slug, OBJECT, 'page');
        $file = get_template_directory() . '/content/' . $slug . '.html';
        $html = is_readable($file) ? file_get_contents($file) : '';
        $content = "<!-- wp:html -->\n" . trim($html) . "\n<!-- /wp:html -->";
        if ($existing) { $id = $existing->ID; wp_update_post(array('ID' => $id, 'post_content' => $content)); }
        else {
            $id = wp_insert_post(array('post_type' => 'page', 'post_status' => 'publish', 'post_name' => $slug,
                'post_title' => $slug === 'home' ? 'Home' : $p['h1'], 'post_content' => $content));
        }
        if (!$id || is_wp_error($id)) { continue; }
        $ids[$slug] = $id;
        update_post_meta($id, '_yt2_title', $p['title']);
        update_post_meta($id, '_yt2_desc', $p['description']);
        if (!empty($p['jsonld'])) { update_post_meta($id, '_yt2_jsonld', $p['jsonld']); }
    }
    $blog = get_page_by_path('blog', OBJECT, 'page');
    if (!$blog) {
        $bid = wp_insert_post(array('post_type' => 'page', 'post_status' => 'publish', 'post_name' => 'blog', 'post_title' => 'Blog', 'post_content' => ''));
        update_post_meta($bid, '_yt2_title', 'Blog | yt2mp4');
        update_post_meta($bid, '_yt2_desc', 'Guides and notes about video formats, MP4 and converting video files.');
    } else { $bid = $blog->ID; }
    if (isset($ids['home'])) { update_option('show_on_front', 'page'); update_option('page_on_front', $ids['home']); }
    if ($bid) { update_option('page_for_posts', $bid); }
    update_option('blogname', $d['siteName']);
    update_option('blogdescription', '');
    update_option('blog_public', !empty($d['indexable']) ? 1 : 0);
    update_option('default_comment_status', 'closed');
    update_option('default_ping_status', 'closed');
    global $wp_rewrite;
    $wp_rewrite->set_permalink_structure('/%postname%/');
    $wp_rewrite->flush_rules(true);

    // Menus
    $make = function ($name, $items) use ($ids, $bid) {
        $m = wp_get_nav_menu_object($name);
        $mid = $m ? $m->term_id : wp_create_nav_menu($name);
        if (is_wp_error($mid)) { return 0; }
        foreach ($items as $it) {
            $pid = $it === 'blog' ? $bid : (isset($ids[$it[0]]) ? $ids[$it[0]] : 0);
            if ($it === 'blog') { $label = 'Blog'; } else { $label = $it[1]; }
            if (!$pid) { continue; }
            wp_update_nav_menu_item($mid, 0, array('menu-item-title' => $label, 'menu-item-object' => 'page', 'menu-item-object-id' => $pid, 'menu-item-type' => 'post_type', 'menu-item-status' => 'publish'));
        }
        return $mid;
    };
    $primary = $make('Primary', array(array('home', 'Converter'), array('download-your-own-youtube-video', 'YouTube videos'), array('mp4-codecs-explained', 'MP4 explained'), array('troubleshooting', 'Troubleshooting'), 'blog', array('about', 'About')));
    $fpages = $make('Footer pages', array(array('home', 'Converter'), array('download-your-own-youtube-video', 'YouTube videos'), array('mp4-codecs-explained', 'MP4 explained'), array('troubleshooting', 'Troubleshooting'), 'blog'));
    $flegal = $make('Footer legal', array(array('privacy', 'Privacy'), array('terms', 'Terms'), array('contact', 'Contact')));
    set_theme_mod('nav_menu_locations', array('primary' => $primary, 'footer_pages' => $fpages, 'footer_legal' => $flegal));

    $sample = get_page_by_path('sample-page', OBJECT, 'page');
    if ($sample) { wp_trash_post($sample->ID); }
    $hello = get_page_by_path('hello-world', OBJECT, 'post');
    if ($hello) { wp_trash_post($hello->ID); }
    update_option('yt2_seeded', '1');
});

/* breadcrumbs: Home > ... > current */
function yt2_crumbs($trail) {
    $all = array_merge(array(array('Home', home_url('/'))), $trail);
    $n = count($all);
    echo '<nav class="crumbs wrap" aria-label="Breadcrumb"><ol>';
    foreach ($all as $i => $b) {
        if ($i === $n - 1) { echo '<li aria-current="page">' . esc_html($b[0]) . '</li>'; }
        else { echo '<li><a href="' . esc_url($b[1]) . '">' . esc_html($b[0]) . '</a></li>'; }
    }
    echo '</ol></nav>' . "\n";
}
