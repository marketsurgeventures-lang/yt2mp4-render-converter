# WordPress integration backup

Original and saved current files for the Hostinger WordPress site https://yt2mp4.live/, theme `yt2mp4`. This is a source backup, not an installable WordPress plugin or a full database backup.

## Contents and current status

- `original/` contains files captured from the theme/content editors before integration. `home-before-resume.html` is the first saved YouTube homepage before the pause notice was added.
- `updated/` contains the saved theme functions/footer and current Home/About/Privacy/Terms/Download Guide/Troubleshooting content. The current homepage focuses on YouTube links and clearly says conversion is paused.
- `original/front-page.php` and `original/app.js` were preserved without changing their live source. The older local-file tool is not the current homepage's main interface.

Saved changes: the exact Render backend origin in the theme's connection policy, conditional homepage metadata, footer text, supporting content, and the live YouTube source-verification notice. The converter's public Enable checkbox is currently off. A deployed backend and healthy worker do not prove YouTube conversion works.

Page IDs: Home 8; Download Guide 9; Troubleshooting 11; About 12; Privacy 14; Terms 15. Settings are under Settings → Render Converter. The shortcode is `[render_video_converter]`.

## Restore a specific file

Use the authenticated WordPress theme/content editor and the corresponding original file. Back up any newer site changes before restoring. For theme CodeMirror source, select all with Meta+A, remove the existing content, then paste the complete file; verify “File edited successfully”. Ordinary page Code editor content can be replaced and saved; verify “Page updated”. The Hostinger Agent overlay may need closing if it covers Save.

Do not blindly restore every file, create a second homepage, reset secrets or enable unverified public source requests. This archive contains no WordPress login password, shared-secret value, account cookie, card information or database dump. Plugin/backend configuration remains saved on the two servers and is not copied here.
