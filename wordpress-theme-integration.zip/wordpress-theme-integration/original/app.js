// yt2mp4 converter: runs entirely in the browser with FFmpeg.wasm (single-thread core, self-hosted).
// No file data is sent to any server. See /privacy/.
import { FFmpeg } from '/wp-content/themes/yt2mp4/assets/vendor/ffmpeg/index.js';

const MAX_MB = Number(document.documentElement.dataset.maxMb || 500);
const CORE = '/wp-content/themes/yt2mp4/assets/vendor/ffmpeg-core/ffmpeg-core.js';
const WASM = '/wp-content/plugins/yt2mp4-wasm/ffmpeg-core.wasm';
const $ = id => document.getElementById(id);

const el = {
  drop: $('drop'), file: $('file'), tally: $('tally'), tallyText: $('tally-text'),
  empty: $('stage-empty'), ready: $('stage-ready'), work: $('stage-work'), done: $('stage-done'),
  specs: $('specs'), outSpecs: $('out-specs'), method: $('opt-method'), size: $('opt-size'), quality: $('opt-quality'), hint: $('method-hint'),
  convert: $('convert'), other: $('choose-other'), cancel: $('cancel'), again: $('again'),
  tc: $('timecode'), bar: $('bar'), status: $('status'), preview: $('preview'), download: $('download')
};
if (!el.drop) throw new Error('tool markup missing');

const S = { ffmpeg: null, loaded: false, file: null, info: null, url: null, running: false, cancelled: false, timer: null, started: 0, lastPct: -1 };

function show(stage) {
  for (const k of ['empty', 'ready', 'work', 'done']) el[k].hidden = k !== stage;
}
function setTally(state, text) { el.tally.dataset.state = state; el.tallyText.textContent = text; }
function say(msg, kind = '') { el.status.textContent = msg; el.status.className = 'status ' + kind; }
function fmtBytes(n) { if (n < 1024 * 1024) return (n / 1024).toFixed(0) + ' KB'; if (n < 1024 ** 3) return (n / 1024 / 1024).toFixed(1) + ' MB'; return (n / 1024 ** 3).toFixed(2) + ' GB'; }
function pad(n) { return String(Math.floor(n)).padStart(2, '0'); }
function fmtTc(sec) { sec = Math.max(0, sec); return `${pad(sec / 3600)}:${pad((sec % 3600) / 60)}:${pad(sec % 60)}`; }
function fmtDur(sec) { return sec == null ? 'Unknown' : fmtTc(sec); }

function unsupported() {
  return typeof WebAssembly !== 'object' || typeof Worker === 'undefined' || typeof Blob === 'undefined';
}

// ---------- ffmpeg lifecycle
let logSink = null;
async function ensureFFmpeg() {
  if (S.ffmpeg && S.loaded) return S.ffmpeg;
  const ff = new FFmpeg();
  ff.on('log', ({ message }) => { if (logSink) logSink.push(message); });
  ff.on('progress', ({ time }) => onProgress(time));
  S.ffmpeg = ff; S.loaded = false;
  await ff.load({ coreURL: CORE, wasmURL: WASM });
  S.loaded = true;
  return ff;
}
function killFFmpeg() {
  try { S.ffmpeg && S.ffmpeg.terminate(); } catch { /* already gone */ }
  S.ffmpeg = null; S.loaded = false;
}

// ---------- probe via `ffmpeg -i` log output
function parseProbe(lines) {
  const text = lines.join('\n');
  const info = { container: null, duration: null, video: null, audio: null };
  const inp = text.match(/Input #0, ([^,]+(?:,[^,]+)*?), from/);
  if (inp) info.container = inp[1].split(',')[0];
  const d = text.match(/Duration: (\d+):(\d+):(\d+(?:\.\d+)?)/);
  if (d) info.duration = (+d[1]) * 3600 + (+d[2]) * 60 + parseFloat(d[3]);
  for (const line of lines) {
    if (/Stream #0:\d+.*Video:/.test(line) && !info.video && !/attached pic/.test(line)) {
      const codec = line.match(/Video: ([\w-]+)/)?.[1];
      const res = line.match(/, (\d{2,5})x(\d{2,5})/);
      const fps = line.match(/([\d.]+) fps/);
      info.video = { codec, w: res ? +res[1] : null, h: res ? +res[2] : null, fps: fps ? parseFloat(fps[1]) : null };
    } else if (/Stream #0:\d+.*Audio:/.test(line) && !info.audio) {
      info.audio = { codec: line.match(/Audio: ([\w-]+)/)?.[1] };
    }
  }
  return info;
}

async function probe(file) {
  const ff = await ensureFFmpeg();
  try { await ff.createDir('/in'); } catch { /* exists */ }
  await ff.mount('WORKERFS', { files: [file] }, '/in');
  const lines = []; logSink = lines;
  try { await ff.exec(['-hide_banner', '-i', '/in/' + file.name], 30000); } finally { logSink = null; }
  return parseProbe(lines);
}

// ---------- options derived from the real source
function methodDecision(info, methodPref, targetH) {
  const v = info.video, a = info.audio;
  const needsScale = targetH && v.h && targetH < v.h;
  const copyOk = v.codec === 'h264' && (!a || ['aac', 'mp3'].includes(a.codec)) && !needsScale;
  if (methodPref === 'encode') return 'encode';
  return copyOk ? 'copy' : 'encode';
}
function refreshHint() {
  if (!S.info) return;
  const targetH = Number(el.size.value) || 0;
  const m = methodDecision(S.info, el.method.value, targetH);
  el.hint.textContent = m === 'copy'
    ? 'This file already uses MP4-friendly codecs, so the streams will be copied without re-compressing: quick and no quality loss.'
    : 'The video will be re-encoded to H.264 with AAC audio. This takes longer than real time on some devices and cannot be sped up with hardware.';
}
function fillSizes(info) {
  el.size.innerHTML = '';
  const add = (v, t) => { const o = document.createElement('option'); o.value = v; o.textContent = t; el.size.appendChild(o); };
  add('0', info.video.h ? `Original (${info.video.w}×${info.video.h})` : 'Original');
  if (info.video.h) for (const h of [1080, 720, 480, 360]) if (h < info.video.h) add(String(h), `${h}p (smaller)`);
}
function spec(dl, k, v) {
  const d = document.createElement('div'); const dt = document.createElement('dt'); const dd = document.createElement('dd');
  dt.textContent = k; dd.textContent = v; d.append(dt, dd); dl.appendChild(d);
}

// ---------- flow
function reset(keepStatus) {
  if (S.url) { URL.revokeObjectURL(S.url); S.url = null; }
  el.preview.removeAttribute('src'); el.preview.load();
  el.download.removeAttribute('href');
  S.file = null; S.info = null; S.running = false; S.cancelled = false;
  el.file.value = '';
  clearInterval(S.timer);
  show('empty'); setTally('idle', 'Ready');
  if (!keepStatus) say('');
}

async function choose(file) {
  if (S.running) return;
  if (unsupported()) { setTally('error', 'Not supported'); say('This browser cannot run the converter. Use a current version of Chrome, Edge, Firefox or Safari.', 'err'); return; }
  if (!file) { say('Choose a video file to begin.'); return; }
  if (file.size === 0) { setTally('error', 'Empty file'); say('That file is empty (0 bytes). Choose a different file.', 'err'); return; }
  if (file.size > MAX_MB * 1024 * 1024) { setTally('error', 'Too large'); say(`That file is ${fmtBytes(file.size)}. The limit is ${MAX_MB} MB. Choose a smaller file, or trim it first.`, 'err'); return; }
  S.file = file; S.info = null;
  setTally('working', 'Reading file'); say('Reading the file. The first visit also loads the converter (about 31 MB).');
  show('work'); el.bar.classList.add('indet'); el.bar.firstElementChild.style.width = ''; el.tc.textContent = '--:--:--'; el.cancel.hidden = true;
  try {
    const info = await probe(file);
    if (!info.container) throw new Error('unreadable');
    if (!info.video) throw Object.assign(new Error('novideo'), { code: 'novideo' });
    S.info = info;
    el.specs.innerHTML = '';
    spec(el.specs, 'File', file.name);
    spec(el.specs, 'Size', fmtBytes(file.size));
    spec(el.specs, 'Container', info.container || 'Unknown');
    spec(el.specs, 'Video', `${info.video.codec || '?'}${info.video.w ? ` ${info.video.w}×${info.video.h}` : ''}${info.video.fps ? ` ${info.video.fps} fps` : ''}`);
    spec(el.specs, 'Audio', info.audio ? info.audio.codec : 'None');
    spec(el.specs, 'Length', fmtDur(info.duration));
    fillSizes(info); refreshHint();
    el.bar.classList.remove('indet'); el.cancel.hidden = false;
    show('ready'); setTally('idle', 'File ready'); say('Choose options and select Convert to MP4.');
  } catch (e) {
    killFFmpeg(); el.bar.classList.remove('indet'); el.cancel.hidden = false;
    show('empty'); setTally('error', 'Cannot read');
    if (e && e.code === 'novideo') say('No video track was found in this file. This tool converts video files; for audio-only files use an audio converter.', 'err');
    else say('This file could not be read. It may be damaged, incomplete or copy-protected. Check that it plays in a media player, then try again.', 'err');
  }
}

function onProgress(timeUs) {
  if (!S.running || !S.info || !S.info.duration || !(timeUs > 0)) return;
  const pct = Math.min(100, Math.max(0, Math.round((timeUs / 1e6) / S.info.duration * 100)));
  el.bar.classList.remove('indet');
  el.bar.firstElementChild.style.width = pct + '%';
  if (pct >= S.lastPct + 10) { S.lastPct = pct - (pct % 10); say(`Converting: ${pct}% of the video processed.`); }
}

function safeName(name) {
  const base = name.replace(/\.[^.]*$/, '').replace(/[^\w .()-]+/g, '_').replace(/^[. ]+|[. ]+$/g, '').slice(0, 80);
  return (base || 'video') + (/\.mp4$/i.test(name) ? '-converted' : '') + '.mp4';
}

async function convert() {
  if (S.running || !S.file || !S.info) return;
  S.running = true; S.cancelled = false; S.lastPct = -1;
  const file = S.file, info = S.info;
  const targetH = Number(el.size.value) || 0;
  const method = methodDecision(info, el.method.value, targetH);
  const crf = el.quality.value;
  show('work'); setTally('working', 'Converting');
  el.bar.classList.toggle('indet', !info.duration); el.bar.firstElementChild.style.width = '0';
  S.started = performance.now();
  el.tc.textContent = '00:00:00';
  S.timer = setInterval(() => { el.tc.textContent = fmtTc((performance.now() - S.started) / 1000); }, 500);
  say(method === 'copy' ? 'Copying streams into an MP4 container.' : 'Re-encoding to H.264 and AAC.');
  const args = ['-i', '/in/' + file.name, '-map', '0:v:0', '-map', '0:a:0?', '-sn', '-dn'];
  if (method === 'copy') args.push('-c', 'copy');
  else {
    args.push('-c:v', 'libx264', '-preset', 'veryfast', '-crf', crf, '-pix_fmt', 'yuv420p');
    if (targetH) args.push('-vf', `scale=-2:${targetH}`);
    args.push('-c:a', 'aac', '-b:a', '160k');
  }
  args.push('-movflags', '+faststart', 'out.mp4');
  try {
    const ff = await ensureFFmpeg();
    // after a cancel the worker was recreated: remount the input
    try { await ff.createDir('/in'); } catch { /* exists */ }
    try { await ff.mount('WORKERFS', { files: [file] }, '/in'); } catch { /* already mounted */ }
    const code = await ff.exec(args);
    if (S.cancelled) return;
    if (code !== 0) throw new Error('ffmpeg exit ' + code);
    const data = await ff.readFile('out.mp4');
    if (!data || data.length < 1024) throw new Error('empty output');
    const blob = new Blob([data], { type: 'video/mp4' });
    await ff.deleteFile('out.mp4');
    clearInterval(S.timer);
    const secs = (performance.now() - S.started) / 1000;
    S.url = URL.createObjectURL(blob);
    el.preview.src = S.url;
    el.download.href = S.url; el.download.download = safeName(file.name);
    el.outSpecs.innerHTML = '';
    spec(el.outSpecs, 'File', safeName(file.name));
    spec(el.outSpecs, 'Size', fmtBytes(blob.size));
    spec(el.outSpecs, 'Method', method === 'copy' ? 'Streams copied' : `Re-encoded H.264/AAC${targetH ? ' at ' + targetH + 'p' : ''}`);
    spec(el.outSpecs, 'Time taken', fmtTc(secs));
    show('done'); setTally('done', 'Done');
    say('Your MP4 is ready. Download it before you close this page or choose another file.', 'ok');
    el.download.focus();
  } catch (e) {
    clearInterval(S.timer);
    if (S.cancelled) return;
    killFFmpeg();
    show('ready'); setTally('error', 'Failed');
    say('The conversion failed. This often means the browser ran out of memory or the file uses an unsupported feature. Try a smaller resolution or Re-encode for maximum compatibility, close other tabs, or use a smaller file.', 'err');
  } finally {
    S.running = false;
  }
}

function cancel() {
  if (!S.running) return;
  S.cancelled = true; S.running = false;
  clearInterval(S.timer);
  killFFmpeg();
  show('ready'); setTally('idle', 'Cancelled');
  say('Conversion cancelled. Nothing was saved. You can change the options and convert again.');
}

// ---------- events
el.file.addEventListener('change', () => choose(el.file.files[0]));
for (const ev of ['dragenter', 'dragover']) el.drop.addEventListener(ev, e => { e.preventDefault(); el.drop.classList.add('is-over'); });
for (const ev of ['dragleave', 'drop']) el.drop.addEventListener(ev, e => { e.preventDefault(); el.drop.classList.remove('is-over'); });
el.drop.addEventListener('drop', e => { const f = e.dataTransfer?.files?.[0]; if (f) choose(f); });
el.convert.addEventListener('click', convert);
el.cancel.addEventListener('click', cancel);
el.other.addEventListener('click', () => { killFFmpeg(); reset(); });
el.again.addEventListener('click', () => { killFFmpeg(); reset(); });
el.method.addEventListener('change', refreshHint);
el.size.addEventListener('change', refreshHint);
window.addEventListener('beforeunload', e => { if (S.running) { e.preventDefault(); e.returnValue = ''; } });
document.documentElement.dataset.toolReady = '1';

// ---------- YouTube link check (local parsing; optional oEmbed lookup on user action)
(function ytCheck() {
  const form = $('ytform'), input = $('yturl'), out = $('ytout');
  if (!form) return;
  function parse(raw) {
    let u; try { u = new URL(raw.trim()); } catch { return { error: 'That does not look like a web address. Paste the full link, starting with https://.' }; }
    if (!/^https?:$/.test(u.protocol)) return { error: 'Only http and https links are accepted.' };
    const host = u.hostname.replace(/^www\./, '').replace(/^m\./, '');
    const okHosts = ['youtube.com', 'music.youtube.com', 'youtu.be', 'youtube-nocookie.com'];
    if (!okHosts.includes(host)) return { error: 'This is not a YouTube link. The checker accepts youtube.com and youtu.be links.' };
    let id = null;
    if (host === 'youtu.be') id = u.pathname.split('/')[1];
    else if (u.pathname === '/watch') id = u.searchParams.get('v');
    else { const m = u.pathname.match(/^\/(shorts|live|embed)\/([^/]+)/); if (m) id = m[2]; }
    if (id && /^[\w-]{11}$/.test(id)) return { id };
    if (u.pathname === '/playlist' && u.searchParams.get('list')) return { playlist: true };
    return { error: 'No video was found in that link. Open the video and copy the address from the browser or the Share button.' };
  }
  function p(text) { const e = document.createElement('p'); e.textContent = text; return e; }
  function guide(label, href, text) { const li = document.createElement('li'); const a = document.createElement('a'); a.href = href; a.textContent = label; if (/^https?:/.test(href)) a.rel = 'noopener'; li.append(a, document.createTextNode(text)); return li; }
  async function oembed(id) {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 6000);
    try {
      const r = await fetch('https://www.youtube.com/oembed?format=json&url=' + encodeURIComponent('https://www.youtube.com/watch?v=' + id), { signal: ctl.signal, credentials: 'omit', referrerPolicy: 'no-referrer' });
      if (!r.ok) return null; return await r.json();
    } catch { return null; } finally { clearTimeout(t); }
  }
  form.addEventListener('submit', async e => {
    e.preventDefault(); out.replaceChildren();
    const r = parse(input.value);
    if (r.error) { out.appendChild(p(r.error)); return; }
    if (r.playlist) { out.appendChild(p('This is a playlist link. yt2mp4 does not download playlists or videos from YouTube. Use the options below for videos you own.')); }
    if (r.id) {
      const info = await oembed(r.id);
      const card = document.createElement('div'); card.className = 'card';
      if (info && info.thumbnail_url && /^https:\/\/i\.ytimg\.com\//.test(info.thumbnail_url)) { const img = document.createElement('img'); img.src = info.thumbnail_url; img.alt = ''; img.width = 120; img.height = 68; card.appendChild(img); }
      const box = document.createElement('div');
      const h = document.createElement('strong'); h.textContent = info && info.title ? info.title : 'Video found';
      box.append(h, p(info && info.author_name ? 'Channel: ' + info.author_name : 'The title could not be loaded right now. The link is still valid.'));
      card.appendChild(box); out.appendChild(card);
    }
    out.appendChild(p('yt2mp4 cannot download this video. Which applies to you?'));
    const ul = document.createElement('ul');
    ul.append(
      guide('I uploaded it', '/download-your-own-youtube-video/', ': download it from YouTube Studio, then convert it here if needed.'),
      guide('Someone else made it', 'https://support.google.com/youtube/answer/11977233', ': YouTube Premium can save it for offline viewing in the YouTube app, or ask the creator for the file.')
    );
    out.appendChild(ul);
  });
})();
