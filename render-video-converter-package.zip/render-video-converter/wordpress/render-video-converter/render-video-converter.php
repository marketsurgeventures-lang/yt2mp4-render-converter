<?php
/**
 * Plugin Name: Render Video Converter
 * Description: A YouTube MP4/MP3 frontend using your own Render conversion engine.
 * Version: 1.0.0
 * Requires at least: 6.3
 * Requires PHP: 8.1
 * License: GPL-2.0-or-later
 */
namespace MSVCR;
if (!defined('ABSPATH')) { exit; }
require_once __DIR__ . '/includes/input.php';
final class Plugin {
    public const VERSION = '1.0.0';
    public const OPTION = 'msvcr_settings';
    public static function defaults(): array { return ['enabled'=>false,'backend_url'=>'','secret'=>'','daily'=>20,'rate'=>5]; }
    public static function config(): array { return array_merge(self::defaults(), (array)get_option(self::OPTION, [])); }
    private static function siteOrigin(): string {
        $p=wp_parse_url(home_url());
        return ($p['scheme']??'https').'://'.($p['host']??'').(isset($p['port'])?':'.$p['port']:'');
    }
    private static function fingerprint(array $c): string { return hash('sha256', wp_json_encode($c)); }
    private static function ready(array $c): bool {
        $r = get_option('msvcr_report', []);
        return !empty($c['enabled']) && strlen($c['secret']) === 64 && !empty($r['ok']) && ($r['fingerprint'] ?? '') === self::fingerprint($c);
    }
    private static function backend(string $url): string {
        $p = wp_parse_url($url);
        $host = strtolower($p['host'] ?? '');
        if (!$p || ($p['scheme'] ?? '') !== 'https' || filter_var($host,FILTER_VALIDATE_IP) || !preg_match('/^(?=.{4,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/D',$host) || isset($p['user']) || isset($p['pass']) || isset($p['port']) || isset($p['query']) || isset($p['fragment']) || !in_array($p['path'] ?? '', ['', '/'], true)) {
            throw new \RuntimeException('Enter your backend HTTPS domain, for example https://converter.yourdomain.com, without a path.');
        }
        return 'https://' . $host;
    }
    public static function boot(): void {
        add_action('rest_api_init', [self::class, 'routes']);
        add_action('wp_enqueue_scripts', [self::class, 'assets']);
        add_shortcode('render_video_converter', [self::class, 'shortcode']);
        add_action('admin_menu', fn() => add_options_page('Render Video Converter','Render Video Converter','manage_options','msvcr',[self::class,'settingsPage']));
        add_action('admin_init', fn() => register_setting('msvcr',self::OPTION,['sanitize_callback'=>[self::class,'sanitizeSettings']]));
        add_action('admin_post_msvcr_check', [self::class,'checkAction']);
        add_filter('rest_post_dispatch', function($response,$server,$request) {
            if (str_starts_with($request->get_route(),'/msvcr/v1/')) { $response=rest_ensure_response($response); $response->header('Cache-Control','private, no-store'); $response->header('X-Robots-Tag','noindex, nofollow'); }
            return $response;
        },10,3);
    }
    public static function assets(): void {
        wp_register_style('msvcr-tool', plugins_url('assets/tool.css', __FILE__), [], self::VERSION);
        wp_register_script('msvcr-tool', plugins_url('assets/tool.js', __FILE__), [], self::VERSION, true);
        global $post;
        if ($post && has_shortcode($post->post_content ?? '', 'render_video_converter')) { wp_enqueue_style('msvcr-tool'); wp_enqueue_script('msvcr-tool'); }
    }
    public static function shortcode($attributes = []): string {
        $attributes = shortcode_atts(['mode' => 'mp4', 'title' => 'YouTube to MP4 & MP3'], $attributes, 'render_video_converter');
        wp_enqueue_style('msvcr-tool'); wp_enqueue_script('msvcr-tool');
        $uid = wp_unique_id('msvcr-');
        $config = ['api' => esc_url_raw(rest_url('msvcr/v1/')), 'download' => esc_url_raw(admin_url('admin-post.php')), 'transport' => 'render', 'backend' => self::config()['backend_url'], 'mode' => $attributes['mode'] === 'mp3' ? 'mp3' : 'mp4'];
        ob_start();
        // Page builders can render shortcodes after wp_head; print this handle once.
        if (!wp_style_is('msvcr-tool', 'done')) { wp_print_styles('msvcr-tool'); }
        ?>
        <section class="msvc" data-msvcr="<?php echo esc_attr(wp_json_encode($config)); ?>" aria-labelledby="<?php echo esc_attr($uid); ?>title">
            <div class="msvc-heading"><span class="msvc-eyebrow">MP4 VIDEO · MP3 AUDIO</span><h2 id="<?php echo esc_attr($uid); ?>title"><?php echo esc_html($attributes['title']); ?></h2><p>Paste a YouTube link. Choose your format. Download your file.</p></div>
            <form class="msvc-form" novalidate>
                <label class="msvc-label" for="<?php echo esc_attr($uid); ?>url">YouTube video link</label>
                <div class="msvc-input-row"><input id="<?php echo esc_attr($uid); ?>url" name="video_url" type="url" placeholder="Paste YouTube link" required autocomplete="off" inputmode="url" maxlength="2048"><button class="msvc-paste" type="button" aria-label="Paste a video link">Paste</button><button class="msvc-start" type="submit" disabled>Start <span aria-hidden="true">→</span></button></div>
                <label class="msvc-consent"><input type="checkbox" name="authorized" required><span>I own this video or have permission to download it.</span></label>
                <p class="msvc-limits"></p>
            </form>
            <div class="msvc-status" role="status" aria-live="polite" aria-atomic="true" hidden></div>
            <div class="msvc-progress" hidden><div class="msvc-progress-track" role="progressbar" aria-label="Conversion progress" aria-valuemin="0" aria-valuemax="100"><span></span></div><button type="button" class="msvcr-cancel" hidden>Cancel request</button></div>
            <div class="msvc-result" hidden>
                <div class="msvc-video"><img class="msvc-thumbnail" alt="Video thumbnail" loading="lazy" referrerpolicy="no-referrer"><div><h3 class="msvc-video-title"></h3><p class="msvc-duration"></p></div></div>
                <div class="msvc-tabs" role="group" aria-label="Output format"><button type="button" class="msvc-tab" data-format="mp4" aria-pressed="true">MP4 · Video</button><button type="button" class="msvc-tab" data-format="mp3" aria-pressed="false">MP3 · Audio</button></div>
                <div class="msvc-quality-wrap"><label class="msvc-label" for="<?php echo esc_attr($uid); ?>quality">Choose quality</label><div class="msvc-convert-row"><select id="<?php echo esc_attr($uid); ?>quality" class="msvc-quality"></select><button type="button" class="msvc-convert">Convert</button></div><p class="msvc-quality-note"></p></div>
            </div>
            <div class="msvc-download" hidden><div><strong>Your file is ready</strong><p class="msvc-download-meta"></p></div><a class="msvc-download-link" rel="nofollow noreferrer">Download <span aria-hidden="true">↓</span></a></div>
            <div class="msvc-help"><div><span>1</span><p>Paste your video link</p></div><div><span>2</span><p>Select MP4 or MP3</p></div><div><span>3</span><p>Convert and download</p></div></div>
            <noscript><p>Enable JavaScript to use this converter.</p></noscript>
        </section>
        <?php return (string)ob_get_clean();
    }
    private static function cookieName(): string { return 'msvcr_session_' . substr(md5(home_url()), 0, 10); }
    private static function sessionId(): ?string {
        $value = $_COOKIE[self::cookieName()] ?? '';
        if (!is_string($value) || !preg_match('/^([a-f0-9]{64})\.([a-f0-9]{64})$/D', $value, $m)) { return null; }
        return hash_equals(hash_hmac('sha256', $m[1], wp_salt('auth')), $m[2]) ? $m[1] : null;
    }
    private static function token(string $session, int $bucket): string { return hash_hmac('sha256', $session . ':' . $bucket, wp_salt('nonce')); }
    private static function owner(): string { return hash_hmac('sha256', self::sessionId() ?? '', wp_salt('auth')); }
    public static function sameOrigin($request) {
        $origin = $request->get_header('origin');
        if ($request->get_header('sec-fetch-site') === 'cross-site') { return new \WP_Error('msvc_origin', 'Open the converter on this website.', ['status' => 403]); }
        if ($origin) {
            $given = wp_parse_url($origin); $home = wp_parse_url(home_url());
            $port = fn($u) => (int)($u['port'] ?? (($u['scheme'] ?? '') === 'https' ? 443 : 80));
            if (!$given || strtolower($given['host'] ?? '') !== strtolower($home['host'] ?? '') || ($given['scheme'] ?? '') !== ($home['scheme'] ?? '') || $port($given) !== $port($home)) {
                return new \WP_Error('msvc_origin', 'Open the converter on this website.', ['status' => 403]);
            }
        }
        return true;
    }
    public static function authorize($request) {
        $origin = self::sameOrigin($request); if (is_wp_error($origin)) { return $origin; }
        $session = self::sessionId(); $provided = (string)$request->get_header('x-msvc-token'); $bucket = (int)floor(time() / 1800);
        if (!$session || !(hash_equals(self::token($session, $bucket), $provided) || hash_equals(self::token($session, $bucket - 1), $provided))) {
            return new \WP_Error('msvc_session', 'Your session expired. Refresh the page and try again.', ['status' => 403]);
        }
        return true;
    }

    public static function routes(): void {
        register_rest_route('msvcr/v1','/session',['methods'=>'POST','callback'=>[self::class,'session'],'permission_callback'=>[self::class,'sameOrigin']]);
        foreach (['analyze','convert'] as $name) { register_rest_route('msvcr/v1','/'.$name,['methods'=>'POST','callback'=>[self::class,$name],'permission_callback'=>[self::class,'authorize']]); }
    }
    public static function session($request) {
        $id = self::sessionId();
        if (!$id) {
            $id=bin2hex(random_bytes(32)); $cookie=$id.'.'.hash_hmac('sha256',$id,wp_salt('auth'));
            setcookie(self::cookieName(),$cookie,['expires'=>time()+7200,'path'=>'/','secure'=>is_ssl(),'httponly'=>true,'samesite'=>'Strict']); $_COOKIE[self::cookieName()]=$cookie;
        }
        $limits=get_option('msvcr_report',[])['limits']??[];
        return new \WP_REST_Response(['token'=>self::token($id,(int)floor(time()/1800)),'available'=>self::ready(self::config()),'max_minutes'=>(int)($limits['max_minutes']??2),'max_mb'=>(int)($limits['max_mb']??20),'max_height'=>(int)($limits['max_height']??360),'timeout'=>(int)($limits['timeout']??600),'ttl'=>(int)($limits['ttl']??10),'queue_timeout'=>(int)($limits['queue_timeout']??900)],200);
    }
    private static function admit(string $kind, array $config): void {
        $lock = bin2hex(random_bytes(16)); $lockKey = 'msvcr_admission_lock';
        if (!add_option($lockKey,['id'=>$lock,'expires'=>time()+15],'','no')) {
            $old=get_option($lockKey,[]);
            if (($old['expires']??PHP_INT_MAX)<time()) { delete_option($lockKey); }
            throw new \RuntimeException('The converter is busy. Try again shortly.');
        }
        try {
            $day = gmdate('Ymd'); $dailyKey = 'msvcr_day_'.$kind.'_'.$day;
            $count = (int)get_transient($dailyKey); $max = (int)$config['daily'] * ($kind==='analyze' ? 2 : 1);
            if ($count >= $max) { throw new \RuntimeException('Today’s converter limit has been reached. Try again tomorrow.'); }
            $ip = hash_hmac('sha256',$_SERVER['REMOTE_ADDR']??'unknown',wp_salt('auth'));
            $bucket = (int)floor(time()/600); $limit = (int)$config['rate']*($kind==='analyze'?2:1);
            $keys = ['msvcr_rate_'.hash('sha256',$kind.$bucket.self::owner())=>$limit,'msvcr_rate_'.hash('sha256',$kind.$bucket.$ip)=>$limit*4];
            foreach ($keys as $key=>$maximum) { if ((int)get_transient($key)>=$maximum) { throw new \RuntimeException('Request limit reached. Try again in 10 minutes.'); } }
            foreach ($keys as $key=>$maximum) { set_transient($key,(int)get_transient($key)+1,1200); }
            set_transient($dailyKey,$count+1,172800);
        } finally { $current=get_option($lockKey,[]); if (($current['id']??'')===$lock) { delete_option($lockKey); } }
    }
    private static function issue(string $kind, array $body) {
        $c=self::config(); if (!self::ready($c)) { throw new \RuntimeException('The converter is not available yet. Please try later.'); }
        self::admit($kind,$c); $id=bin2hex(random_bytes(16));
        $p=array_merge($body,['kind'=>$kind,'id'=>$id,'owner'=>self::owner(),'origin'=>self::siteOrigin(),'exp'=>time()+120]);
        $encoded=rtrim(strtr(base64_encode(wp_json_encode($p)),'+/','-_'),'=');
        $ticket=$encoded.'.'.hash_hmac('sha256',$encoded,$c['secret']);
        set_transient('msvcr_job_'.$id,['owner'=>self::owner(),'kind'=>$kind,'created'=>time()],7200);
        return new \WP_REST_Response(['job'=>$id,'kind'=>$kind,'worker'=>self::backend($c['backend_url']),'ticket'=>$ticket],202);
    }
    public static function analyze($request) {
        try {
            if ($request->get_param('authorized')!==true) { throw new \RuntimeException('Confirm that you have permission to download this video.'); }
            $url=$request->get_param('url'); if (!is_string($url)) { throw new \RuntimeException('Paste a YouTube video link.'); }
            return self::issue('analyze',['url'=>Input::video($url)['url']]);
        } catch (\Throwable $e) { return new \WP_Error('msvcr_error',$e->getMessage(),['status'=>400]); }
    }
    public static function convert($request) {
        try {
            if ($request->get_param('authorized')!==true) { throw new \RuntimeException('Confirm that you have permission to download this video.'); }
            $id=$request->get_param('analysis'); if (!is_string($id) || !preg_match('/^[a-f0-9]{32}$/D',$id)) { throw new \RuntimeException('Check the video link again.'); }
            $job=get_transient('msvcr_job_'.$id);
            if (!$job || $job['kind']!=='analyze' || !hash_equals($job['owner'],self::owner())) { throw new \RuntimeException('The video analysis has expired. Check the link again.'); }
            $format=$request->get_param('format'); $quality=$request->get_param('quality');
            if (!is_int($quality) || !in_array($format,['mp3','mp4'],true) || ($format==='mp3'&&!in_array($quality,[128,192,320],true)) || ($format==='mp4'&&($quality<1||$quality>720))) { throw new \RuntimeException('Choose a valid quality.'); }
            return self::issue('convert',['analysis'=>$id,'format'=>$format,'quality'=>$quality]);
        } catch (\Throwable $e) { return new \WP_Error('msvcr_error',$e->getMessage(),['status'=>400]); }
    }
    public static function sanitizeSettings($input): array {
        $old=self::config(); $input=is_array($input)?$input:[];
        try { $url=self::backend(trim((string)($input['backend_url']??''))); }
        catch (\Throwable $e) { add_settings_error(self::OPTION,'url',$e->getMessage()); return $old; }
        $secret=trim((string)($input['secret']??'')); if ($secret==='') { $secret=$old['secret']; }
        if (!empty($input['remove_secret'])) { $secret=''; }
        if ($secret!==''&&!preg_match('/^[a-f0-9]{64}$/D',$secret)) { add_settings_error(self::OPTION,'secret','Use the random 64-character lowercase hex secret saved in Render environment settings.'); return $old; }
        return ['enabled'=>!empty($input['enabled']),'backend_url'=>$url,'secret'=>$secret,'daily'=>min(200,max(1,(int)($input['daily']??20))),'rate'=>min(30,max(1,(int)($input['rate']??5)))];
    }
    public static function checkAction(): void {
        if (!current_user_can('manage_options')) { wp_die('Not allowed.','',['response'=>403]); }
        check_admin_referer('msvcr_check'); $c=self::config(); $report=['ok'=>false,'fingerprint'=>self::fingerprint($c)];
        try {
            if (strlen($c['secret'])!==64) { throw new \RuntimeException('Save the shared secret first.'); }
            $r=wp_remote_get(self::backend($c['backend_url']).'/health',['timeout'=>25,'redirection'=>0,'sslverify'=>true,'limit_response_size'=>65536,'headers'=>['Authorization'=>'Bearer '.$c['secret']]]);
            if (is_wp_error($r)) { throw new \RuntimeException('Could not connect to the Render backend.'); }
            $data=json_decode(wp_remote_retrieve_body($r),true);
            if (wp_remote_retrieve_response_code($r)!==200||empty($data['ok'])) { throw new \RuntimeException($data['message']??'The Render backend did not pass checks.'); }
            if (($data['origin']??'')!==self::siteOrigin()) { throw new \RuntimeException('The backend origin must match the WordPress website origin exactly.'); }
            $report['ok']=true; $report['limits']=$data['limits']??[]; $report['message']='Connected. Worker, storage and engine checks passed. Live YouTube processing still needs a test.';
        } catch (\Throwable $e) { $report['message']=$e->getMessage(); }
        update_option('msvcr_report',$report,false); wp_safe_redirect(admin_url('options-general.php?page=msvcr')); exit;
    }
    public static function settingsPage(): void {
        if (!current_user_can('manage_options')) { return; } $c=self::config(); $r=get_option('msvcr_report',[]);
        ?><div class="wrap"><h1>Render Video Converter</h1><p>Deploy your own backend from the Render package, then enter its service URL and secret. On a free service, open its healthz URL first to wake it before checking this connection. Add <code>[render_video_converter]</code> to your WordPress page. WordPress itself needs no FFmpeg or VPS.</p><?php settings_errors(); ?>
        <form action="options.php" method="post"><?php settings_fields('msvcr'); ?><table class="form-table">
        <tr><th>Enable</th><td><input type="checkbox" name="msvcr_settings[enabled]" value="1" <?php checked($c['enabled']); ?>></td></tr>
        <tr><th>Backend URL</th><td><input class="regular-text" type="url" name="msvcr_settings[backend_url]" value="<?php echo esc_attr($c['backend_url']); ?>" placeholder="https://converter.yourdomain.com"></td></tr>
        <tr><th>Shared secret</th><td><input class="regular-text" type="password" autocomplete="new-password" name="msvcr_settings[secret]" value="" placeholder="<?php echo $c['secret']?'Saved — leave blank to keep':'Paste the generated secret'; ?>"><p>Saved server-side; never sent to visitors. <label><input type="checkbox" name="msvcr_settings[remove_secret]" value="1"> Remove saved secret</label></p></td></tr>
        <tr><th>Conversions per day, whole site</th><td><input type="number" min="1" max="200" name="msvcr_settings[daily]" value="<?php echo (int)$c['daily']; ?>"><p>Free pilot default 20. Analysis limit is twice this amount. Set the same limit in Render. Render also applies bandwidth and compute limits. Requests, including failures, use a slot. Resets at midnight UTC. This limit does not guarantee a zero hosting bill.</p></td></tr>
        <tr><th>Conversions per visitor / 10 minutes</th><td><input type="number" min="1" max="30" name="msvcr_settings[rate]" value="<?php echo (int)$c['rate']; ?>"></td></tr>
        </table><?php submit_button('Save settings'); ?></form>
        <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post"><input type="hidden" name="action" value="msvcr_check"><?php wp_nonce_field('msvcr_check'); submit_button('Check Render connection','secondary'); ?></form>
        <?php if ($r) { ?><p><strong><?php echo self::ready($c)?'Ready':'Setup required'; ?></strong>: <?php echo esc_html($r['message']??'Run a connection check.'); ?></p><?php } ?></div><?php
    }
}
Plugin::boot();
