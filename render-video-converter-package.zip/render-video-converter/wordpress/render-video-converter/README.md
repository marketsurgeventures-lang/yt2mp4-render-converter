# Render Video Converter — WordPress plugin

Install **render-wordpress-plugin.zip** in WordPress → Plugins → Add New → Upload Plugin, then activate it. The equivalent inner ZIP in the full package is `wordpress/render-video-converter.zip`. Do not upload the full backend package as a WordPress plugin.

Requires WordPress 6.3+ and PHP 8.1+. Your Hostinger WordPress server does not need FFmpeg, shell access or a VPS. Deploy the companion Docker backend on Render first; the backend performs extraction, queueing, MP4/MP3 conversion and signed downloads using its own local yt-dlp and FFmpeg.

## Connect your backend

1. In Settings → Render Video Converter, enter your actual Render HTTPS service URL, without a path or trailing slash.
2. Paste the same private 64-character lowercase hexadecimal secret stored in Render as `MSVCR_SHARED_SECRET`. Enable the tool and save. Leave the daily allowance at **20** to match the default backend.
3. Open the backend's `/healthz` URL to wake it. When it returns `{"ok":true,"configured":true}`, click **Check Render connection** in WordPress. The configured `WORDPRESS_ORIGIN` must exactly match WordPress's home URL origin, including `www` if used.
4. Add `[render_video_converter]` to a Shortcode block or Elementor Shortcode widget. Publish and test a short video you own or have permission to download.

Optional: `[render_video_converter mode="mp3" title="YouTube to MP3"]`.

The default pilot allows two-minute videos, source qualities up to 360p, 20 MiB final files and 10-minute download retention. Requests that fail or are abandoned still use allowance. UTC midnight is 5 AM in Pakistan. Read the full package's `RENDER-SETUP.md` for hosting limits and billing behavior.

The secret is never included in frontend HTML. Guest cookies and CSRF tokens protect ticket issuance; random request capabilities protect status and cancellation. Refresh can recover a pending request only while its backend state and browser storage survive. An interrupted or missing request must be started again.

Exclude `/wp-json/msvcr/v1/*` from WordPress/CDN caching. Allow the Render domain in `connect-src`, and YouTube thumbnail hosts in `img-src`, if your site uses a Content Security Policy. Purge page caches after configuration changes.

Connection checks verify the daemon and installed engine. They do not verify live YouTube access. The local test suite uses a WordPress adapter, not a full WordPress installation.
