/* Original, dependency-free frontend. All processing requests go to WordPress. */
(() => {
  'use strict';
  const sessions = new Map();
  const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const durationText = (seconds) => {
    const total = Math.round(seconds);
    return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, '0')}`;
  };

  async function session(base, refresh = false) {
    if (refresh) sessions.delete(base);
    if (!sessions.has(base)) {
      const promise = fetch(`${base}session`, {
        method: 'POST', credentials: 'same-origin', cache: 'no-store',
        headers: { 'Content-Type': 'application/json' }, body: '{}',
      }).then(async (response) => {
        const data = await response.json();
        if (!response.ok) throw new Error(data.message || 'Could not initialize the converter.');
        return data;
      }).catch((error) => { sessions.delete(base); throw error; });
      sessions.set(base, promise);
    }
    return sessions.get(base);
  }

  function mount(root) {
    if (JSON.parse(root.dataset.msvcr).transport !== 'render') return;
    if (root.dataset.msvcrMounted) return;
    root.dataset.msvcrMounted = '1';
    const options = JSON.parse(root.dataset.msvcr);
    const apiBase = new URL(options.api, window.location.href);
    const form = root.querySelector('.msvc-form');
    const input = form.querySelector('[name="video_url"]');
    const consent = form.querySelector('[name="authorized"]');
    const start = root.querySelector('.msvc-start');
    const paste = root.querySelector('.msvc-paste');
    const convert = root.querySelector('.msvc-convert');
    const select = root.querySelector('.msvc-quality');
    const tabs = Array.from(root.querySelectorAll('.msvc-tab'));
    const status = root.querySelector('.msvc-status');
    const progress = root.querySelector('.msvc-progress');
    const bar = root.querySelector('.msvc-progress-track');
    const result = root.querySelector('.msvc-result');
    const download = root.querySelector('.msvc-download');
    const cancel = root.querySelector('.msvcr-cancel');
    const storageKey = `msvcr:${apiBase.href}:${options.mode}`;
    let currentJob = null;
    let lastWake = 0;
    let available = false;
    let busy = false;
    let analysis = null;
    let info = null;
    let format = options.mode === 'mp3' ? 'mp3' : 'mp4';
    let settings = { timeout: 600, ttl: 30 };

    const message = (text, error = false) => {
      status.hidden = !text;
      status.textContent = text;
      status.classList.toggle('msvc-error', error);
      status.setAttribute('role', error ? 'alert' : 'status');
    };
    const state = (value) => {
      busy = value;
      input.disabled = busy;
      consent.disabled = busy;
      paste.disabled = busy;
      start.disabled = busy || !available;
      convert.disabled = busy || !analysis || !select.options.length || !consent.checked;
      select.disabled = busy;
      tabs.forEach((tab) => {
        const supported = !info || (tab.dataset.format === 'mp4' ? info.qualities.length > 0 : info.has_audio);
        tab.disabled = busy || !supported;
      });
      root.setAttribute('aria-busy', String(busy));
    };
    const showProgress = (data) => {
      progress.hidden = false;
      const determinate = data.kind === 'convert' && Number.isFinite(data.progress);
      bar.classList.toggle('msvc-indeterminate', !determinate);
      if (determinate) {
        const value = Math.min(100, Math.max(0, data.progress));
        bar.setAttribute('aria-valuenow', String(value));
        bar.firstElementChild.style.width = `${value}%`;
      } else {
        bar.removeAttribute('aria-valuenow');
        bar.firstElementChild.style.width = '';
      }
      bar.setAttribute('aria-valuetext', data.phase || 'Processing');
      message(`${data.phase || 'Processing'}…`);
    };

    async function api(path, body, retried = false) {
      const current = await session(apiBase.href);
      const response = await fetch(`${apiBase.href}${path}`, {
        method: 'POST', credentials: 'same-origin', cache: 'no-store',
        headers: { 'Content-Type': 'application/json', 'X-MSVC-Token': current.token },
        body: JSON.stringify(body),
      });
      let data;
      try { data = await response.json(); }
      catch (_) { throw new Error('The server returned an unexpected response. Please try again later.'); }
      if (!response.ok) {
        if (data.code === 'msvc_session' && !retried) {
          await session(apiBase.href, true);
          return api(path, body, true);
        }
        throw new Error(data.message || 'The request could not be completed.');
      }
      return data;
    }

    const remember = (job) => {
      currentJob = job;
      try { localStorage.setItem(storageKey, JSON.stringify({...job, saved: Date.now()})); } catch (_) {}
    };
    const forget = () => {
      currentJob = null; cancel.hidden = true;
      try { localStorage.removeItem(storageKey); } catch (_) {}
    };
    async function backendFetch(url, body, token, method = 'POST') {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 15000);
      try {
        const response = await fetch(url, {
          method, credentials: 'omit', cache: 'no-store', signal: controller.signal,
          headers: {'Authorization': `Bearer ${token}`, ...(method === 'POST' ? {'Content-Type': 'application/json'} : {})},
          ...(method === 'POST' ? {body: JSON.stringify(body || {})} : {}),
        });
        const data = await response.json();
        if (!response.ok) {
          const error = new Error(data.message || 'The conversion server is unavailable.');
          error.terminal = [400,403,404,409,410,429].includes(response.status);
          throw error;
        }
        return data;
      } finally { clearTimeout(timer); }
    }
    async function wake() {
      if (Date.now() - lastWake < 30000) return;
      const target = new URL(options.backend);
      if (target.protocol !== 'https:' || !['','/'].includes(target.pathname)) throw new Error('The backend URL is invalid.');
      const deadline = Date.now() + 90000;
      message('Starting converter… the first request may take about a minute.');
      while (Date.now() < deadline) {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 12000);
        try {
          const response = await fetch(`${target.origin}/healthz`, {method:'GET',credentials:'omit',cache:'no-store',signal:controller.signal});
          const data = await response.json();
          if (response.ok && data.configured === false) {
            const error = new Error('The converter is still being configured. Please try later.');
            error.terminal = true; throw error;
          }
          if (response.ok && data.ok && data.configured) { lastWake = Date.now(); return; }
        } catch (error) { if (error.terminal) throw error; }
        finally { clearTimeout(timer); }
        await delay(2000);
      }
      throw new Error('The conversion server did not start in time. Please try again shortly.');
    }
    async function poll(job) {
      await wake();
      const worker = new URL(job.worker);
      const configured = new URL(options.backend);
      if (worker.protocol !== 'https:' || worker.origin !== configured.origin || !['','/'].includes(worker.pathname)) throw new Error('The backend URL is invalid.');
      const base = worker.origin;
      if (!job.access_token) {
        const admitted = await backendFetch(`${base}/submit`, {}, job.ticket);
        if (admitted.job !== job.job || !/^[a-f0-9]{64}$/.test(admitted.access_token)) throw new Error('The backend returned invalid authorization.');
        job.access_token = admitted.access_token;
        delete job.ticket;
      }
      remember(job); cancel.hidden = false; cancel.disabled = false;
      const deadline = Date.now() + ((settings.queue_timeout || 1800) + settings.timeout + 120) * 1000;
      try {
        while (Date.now() < deadline) {
          const data = await backendFetch(`${base}/status?id=${encodeURIComponent(job.job)}`, null, job.access_token, 'GET');
          if (data.state === 'failed') { forget(); throw new Error(data.message || 'This request failed.'); }
          if (data.state === 'complete') { forget(); return data; }
          const view = {...data};
          if (data.state === 'queued') view.phase = `Waiting in queue · position ${data.position || 1}`;
          showProgress(view);
          await delay(data.state === 'queued' ? 3000 : 1500);
        }
        throw new Error('The progress check timed out. Refresh this page to check the accepted request.');
      } catch (error) {
        if (error.terminal) forget();
        cancel.hidden = true;
        throw error;
      }
    }
    cancel.addEventListener('click', async () => {
      if (!currentJob?.access_token) return;
      cancel.disabled = true;
      try { await backendFetch(`${new URL(currentJob.worker).origin}/cancel`, {id: currentJob.job}, currentJob.access_token); }
      catch (error) { cancel.disabled = false; message(error.message || 'Could not cancel this request.', true); }
    });

    function qualities() {
      if (!info) return;
      select.replaceChildren();
      tabs.forEach((tab) => tab.setAttribute('aria-pressed', String(tab.dataset.format === format)));
      const values = format === 'mp4' ? info.qualities : [128, 192, 320];
      values.forEach((value) => {
        const option = document.createElement('option');
        option.value = String(value);
        option.textContent = format === 'mp4' ? `${value}p · MP4 video` : `${value} kbps · MP3 audio`;
        select.append(option);
      });
      if (format === 'mp3') select.value = '192';
      root.querySelector('.msvc-quality-note').textContent = format === 'mp4'
        ? 'These options reflect the available source video resolutions.'
        : 'A higher MP3 bitrate does not improve the original audio quality.';
      state(busy);
    }

    tabs.forEach((tab) => tab.addEventListener('click', () => {
      if (busy || !info) return;
      format = tab.dataset.format;
      download.hidden = true;
      qualities();
    }));

    function renderAnalysis(complete, job) {
        info = complete.result; analysis = job.job;
        root.querySelector('.msvc-video-title').textContent = info.title;
        root.querySelector('.msvc-duration').textContent = `Duration: ${durationText(info.duration)}`;
        const thumbnail = root.querySelector('.msvc-thumbnail');
        // Only display a thumbnail on the engine's fixed YouTube thumbnail host.
        const thumbnailUrl = new URL(info.thumbnail);
        if (thumbnailUrl.protocol === 'https:' && thumbnailUrl.hostname === 'i.ytimg.com') thumbnail.src = thumbnailUrl.href;
        if (format === 'mp4' && !info.qualities.length) format = 'mp3';
        if (format === 'mp3' && !info.has_audio) format = 'mp4';
        qualities(); result.hidden = false;
        message('Video checked. Choose a format and quality.');
    }
    function renderDownload(complete) {
        const url = new URL(complete.result.download_url);
        if (url.protocol !== 'https:' || url.origin !== new URL(options.backend).origin || url.pathname !== '/download') throw new Error('The download URL is invalid.');
        const link = root.querySelector('.msvc-download-link');
        link.href = url.href; link.download = complete.result.filename;
        const until = new Date(complete.expires * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        root.querySelector('.msvc-download-meta').textContent = `${complete.result.filename} · ${(complete.result.size / 1048576).toFixed(1)} MB · Available until ${until}`;
        download.hidden = false; message('Conversion complete. Your file is ready to download.');
    }
    const invalidate = () => {
      if (busy) return;
      analysis = null; info = null; result.hidden = true; download.hidden = true;
      message(''); state(false);
    };
    input.addEventListener('input', invalidate);
    consent.addEventListener('change', () => state(busy));
    paste.addEventListener('click', async () => {
      try {
        if (!navigator.clipboard?.readText) throw new Error('Clipboard unavailable');
        input.value = (await navigator.clipboard.readText()).trim().slice(0, 2048);
        invalidate();
        input.focus();
      } catch (_) {
        message('Paste your video link into the input box.');
        input.focus();
      }
    });

    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      if (busy || !available) return;
      if (!input.value.trim()) { message('Paste a YouTube video link first.', true); input.focus(); return; }
      if (!consent.checked) { message('Confirm that you have permission to download this video.', true); consent.focus(); return; }
      analysis = null; info = null; result.hidden = true; download.hidden = true;
      state(true); message('Checking video…');
      try {
        await wake();
        const job = await api('analyze', { url: input.value.trim(), authorized: consent.checked });
        const complete = await poll(job);
        renderAnalysis(complete, job);
      } catch (error) { message(error.message || 'Could not check this video.', true); }
      finally { progress.hidden = true; state(false); }
    });

    convert.addEventListener('click', async () => {
      if (busy || !analysis || !consent.checked) return;
      state(true); download.hidden = true; message('Preparing conversion…');
      try {
        await wake();
        const job = await api('convert', { analysis, format, quality: Number(select.value), authorized: consent.checked });
        const complete = await poll(job);
        renderDownload(complete);
      } catch (error) { message(error.message || 'Could not convert this video.', true); }
      finally { progress.hidden = true; state(false); }
    });

    message('Loading converter…');
    (async () => {
      try {
        if (apiBase.origin !== window.location.origin) throw new Error('The converter URL is not configured correctly.');
        settings = await session(apiBase.href);
        available = settings.available;
        root.querySelector('.msvc-limits').textContent = `Up to ${settings.max_minutes} minutes per video · ${settings.max_mb} MB per download`;
        if (!available) message('The converter is not available yet. Please try again later.', true);
        else {
          message('');
          let saved;
          try { saved = JSON.parse(localStorage.getItem(storageKey) || 'null'); } catch (_) {}
          if (saved?.access_token && saved.saved > Date.now() - 7200000 && saved.worker === options.backend) {
            state(true); message('Checking your previous request…');
            try {
              const complete = await poll(saved);
              if (saved.kind === 'analyze') { input.value = `https://www.youtube.com/watch?v=${complete.result.video_id}`; renderAnalysis(complete, saved); }
              else renderDownload(complete);
            } catch (error) { message(error.message || 'Could not check the previous request.', true); }
            finally { progress.hidden = true; state(false); }
          }
        }
      } catch (_) { message('Could not load the converter. Please refresh the page.', true); }
      state(false);
    })();
  }
  const start = () => document.querySelectorAll('[data-msvcr]').forEach(mount);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
