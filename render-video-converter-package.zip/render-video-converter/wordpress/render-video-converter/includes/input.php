<?php
/** Shared, WordPress-independent validation and private job storage. */
namespace MSVCR;

final class Input {
    public static function video(string $value): array {
        $value = trim($value);
        if (strlen($value) > 2048) { throw new \RuntimeException('The video link is too long.'); }
        if (preg_match('/^[A-Za-z0-9_-]{11}$/D', $value)) {
            $id = $value;
        } else {
            $u = parse_url($value);
            if (!$u || strtolower($u['scheme'] ?? '') !== 'https' || isset($u['user']) || isset($u['pass']) || isset($u['port'])) {
                throw new \RuntimeException('Paste a valid HTTPS YouTube video link.');
            }
            $host = strtolower($u['host'] ?? '');
            $path = $u['path'] ?? '';
            if ($host === 'youtu.be') {
                $id = trim($path, '/');
            } elseif (in_array($host, ['youtube.com', 'www.youtube.com', 'm.youtube.com', 'music.youtube.com'], true)) {
                if ($path === '/watch') {
                    parse_str($u['query'] ?? '', $query);
                    $id = is_string($query['v'] ?? null) ? $query['v'] : '';
                } elseif (preg_match('~^/(?:shorts|embed|live)/([A-Za-z0-9_-]{11})/?$~D', $path, $m)) {
                    $id = $m[1];
                } else { $id = ''; }
            } else { throw new \RuntimeException('Only YouTube video links are supported.'); }
            if (!preg_match('/^[A-Za-z0-9_-]{11}$/D', $id)) {
                throw new \RuntimeException('This link does not contain a valid YouTube video ID.');
            }
        }
        return ['id' => $id, 'url' => 'https://www.youtube.com/watch?v=' . $id];
    }

    public static function filename(string $title, string $format): string {
        $title = preg_replace('/[^\pL\pN _-]+/u', '', $title) ?: 'video';
        $title = trim(preg_replace('/\s+/u', ' ', $title), ' ._-');
        // Keep HTTP headers ASCII; the displayed title retains Unicode.
        $ascii = function_exists('iconv') ? @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $title) : $title;
        $ascii = preg_replace('/[^A-Za-z0-9 _-]/', '', (string)$ascii);
        return (substr(trim($ascii), 0, 100) ?: 'video') . '.' . ($format === 'mp3' ? 'mp3' : 'mp4');
    }

    public static function range(?string $header, int $size): array {
        if (!$header) { return [0, $size - 1, false]; }
        if (!preg_match('/^bytes=(\d*)-(\d*)$/D', trim($header), $m) || ($m[1] === '' && $m[2] === '')) {
            throw new \RuntimeException('Invalid byte range.');
        }
        if ($m[1] === '') {
            $length = (int)$m[2];
            if ($length < 1) { throw new \RuntimeException('Invalid byte range.'); }
            $start = max(0, $size - $length); $end = $size - 1;
        } else {
            $start = (int)$m[1]; $end = $m[2] === '' ? $size - 1 : min((int)$m[2], $size - 1);
        }
        if ($start >= $size || $start < 0 || $end < $start) { throw new \RuntimeException('Invalid byte range.'); }
        return [$start, $end, true];
    }
}
