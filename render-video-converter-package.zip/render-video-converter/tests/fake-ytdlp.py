#!/usr/bin/env python3
"""OFFLINE TEST FIXTURE ONLY. Production uses the real yt-dlp executable."""
import json
import os
import shutil
import sys
import time

args = sys.argv[1:]
if '--version' in args:
    print('2026.10.02-offline-test')
    sys.exit(0)
video_id = args[-1].split('v=')[-1]
if video_id == 'ERRORVIDEO1':
    print('Synthetic extraction failure', file=sys.stderr)
    sys.exit(1)
if video_id == 'SLOWVIDEO01':
    time.sleep(4)
if '--dump-single-json' in args:
    print(json.dumps({
        'id': video_id, 'title': 'Offline test video <script>alert(1)</script>',
        'duration': 7200 if video_id == 'LONGVIDEO01' else 2,
        'is_live': video_id == 'LIVEVIDEO01', '_type': 'video',
        'formats': [
            {'height': 180, 'vcodec': 'avc1', 'acodec': 'aac'},
            {'height': 360, 'vcodec': 'avc1', 'acodec': 'none'},
            {'height': 720, 'vcodec': 'avc1', 'acodec': 'none'},
            {'height': 1080, 'vcodec': 'avc1', 'acodec': 'none'},
            {'vcodec': 'none', 'acodec': 'aac'},
        ],
    }))
else:
    template = args[args.index('-o') + 1]
    source = os.environ['MSVC_TEST_MEDIA']
    shutil.copyfile(source, template.replace('%(ext)s', 'mkv'))
    print('MSVC_PROGRESS:100.0%')
