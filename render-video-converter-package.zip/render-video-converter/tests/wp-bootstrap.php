<?php
/** Minimal WordPress API adapter for offline tests; not a WordPress replacement. */
if (!in_array(PHP_SAPI, ['cli', 'cli-server'], true)) { http_response_code(404); exit; }
$testRoot = getenv('MSVCR_TEST_ROOT') ?: sys_get_temp_dir() . '/msvc-test';
if (!is_dir($testRoot . '/web')) { mkdir($testRoot . '/web', 0700, true); }
if (!defined('ABSPATH')) { define('ABSPATH', $testRoot . '/web/'); }
$_SERVER['DOCUMENT_ROOT'] = $testRoot . '/web';
function home_url() { return getenv('MSVC_TEST_ORIGIN') ?: 'http://127.0.0.1:8876'; }
function wp_salt($scheme) { return 'OFFLINE-TEST-ONLY-' . $scheme . '-DO-NOT-USE-IN-PRODUCTION'; }
function add_action(...$args) {}
function add_filter(...$args) {}
function add_shortcode(...$args) {}
function register_activation_hook(...$args) {}
function register_deactivation_hook(...$args) {}
function apply_filters($name, $value) { return $value; }
function register_rest_route(...$args) {}
function get_option($name, $fallback = []) { return $GLOBALS['msvc_test_options'][$name] ?? msvcr_state_get('option', $name, $fallback); }
function update_option($name, $value, ...$args) { $GLOBALS['msvc_test_options'][$name] = $value; }
function wp_parse_url($url) { return parse_url($url); }
function wp_json_encode($value) { return json_encode($value); }
function is_ssl() { return str_starts_with(home_url(), 'https://'); }
function is_wp_error($value) { return $value instanceof WP_Error; }
function rest_ensure_response($value) { return $value instanceof WP_REST_Response ? $value : new WP_REST_Response($value); }
function plugins_url($path, ...$args) { return home_url() . '/assets/' . basename($path); }
function rest_url($path) { return home_url() . '/wp-json/' . $path; }
function admin_url($path) { return home_url() . '/wp-admin/' . $path; }
function esc_attr($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function esc_html($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function esc_url_raw($value) { return $value; }
function esc_url($value) { return esc_attr($value); }
function sanitize_text_field($value) { return strip_tags((string)$value); }
function shortcode_atts($defaults, $attributes, ...$args) { return array_merge($defaults, (array)$attributes); }
function wp_unique_id($prefix) { static $count = 0; return $prefix . ++$count . '-'; }
function wp_register_style(...$args) {}
function wp_register_script(...$args) {}
function wp_enqueue_style(...$args) {}
function wp_enqueue_script(...$args) {}
function wp_style_is(...$args) { static $printed = false; return $printed; }
function wp_print_styles(...$args) { echo '<link rel="stylesheet" href="' . home_url() . '/assets/tool.css">'; }
function add_settings_error(...$args) {}
function status_header($status) { http_response_code($status); }
function nocache_headers() { header('Cache-Control: no-store'); }
function wp_die($message, $title = '', $args = []) {
    if (PHP_SAPI === 'cli') { throw new RuntimeException($message); }
    http_response_code($args['response'] ?? 500); header('Content-Type: text/plain'); echo $message; exit;
}
class WP_Error {
    public function __construct(public string $code, public string $message, public array $data = []) {}
}
class WP_REST_Response {
    public array $headers = [];
    public function __construct(public $data, public int $status = 200) {}
    public function header($name, $value) { $this->headers[$name] = $value; }
}
class MSVC_Test_Request {
    public function __construct(public array $params = [], public array $headers = []) {}
    public function get_param($key) { return $this->params[$key] ?? null; }
    public function get_header($key) { return $this->headers[strtolower($key)] ?? ''; }
}

function msvcr_state_path($group,$name) { return $GLOBALS['testRoot'].'/'.$group.'-'.hash('sha256',$name).'.json'; }
function msvcr_state_get($group,$name,$fallback=false) { $p=msvcr_state_path($group,$name); return is_file($p)?json_decode(file_get_contents($p),true):$fallback; }
function get_transient($name) { $r=msvcr_state_get('transient',$name); return $r&&$r['exp']>time()?$r['value']:false; }
function set_transient($name,$value,$seconds) { file_put_contents(msvcr_state_path('transient',$name),json_encode(['exp'=>time()+$seconds,'value'=>$value]),LOCK_EX); }
function add_option($name,$value,...$args) { $h=@fopen(msvcr_state_path('option',$name),'x'); if (!$h) return false; fwrite($h,json_encode($value)); fclose($h); return true; }
function delete_option($name) { @unlink(msvcr_state_path('option',$name)); }
require_once dirname(__DIR__).'/wordpress/render-video-converter/render-video-converter.php';
$c=['enabled'=>true,'backend_url'=>'https://converter.fixture.example','secret'=>str_repeat('b',64),'daily'=>200,'rate'=>30];
$GLOBALS['msvc_test_options']['msvcr_settings']=$c;
$GLOBALS['msvc_test_options']['msvcr_report']=['ok'=>true,'fingerprint'=>hash('sha256',json_encode($c))];
