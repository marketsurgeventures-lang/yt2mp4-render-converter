#!/usr/bin/env python3
"""Uses local source fixtures; queue, HTTP transport, signatures and FFmpeg are real."""
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import json
import time

tests=Path(__file__).resolve().parent
php=os.environ.get('MSVCR_TEST_PHP') or shutil.which('php')
node=os.environ.get('MSVC_TEST_NODE') or shutil.which('node')
if not php or not node or not shutil.which('ffmpeg'):
    raise SystemExit('Install PHP CLI with POSIX/OpenSSL, Node.js, FFmpeg/ffprobe, Python and jsdom@26. See VALIDATION.md.')
with tempfile.TemporaryDirectory(prefix='msvcr-offline-') as work:
    root=Path(work);fixture=root/'fixture.mkv'
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','lavfi','-i','testsrc=size=320x180:rate=24','-f','lavfi','-i','sine=frequency=440:sample_rate=44100','-t','2','-c:v','libx264','-threads','1','-pix_fmt','yuv420p','-c:a','aac',str(fixture)],check=True)
    config=root/'config.json'
    config.write_text(json.dumps(dict(secret='b'*64,origin='https://fixture.example',backend_url='https://converter.fixture.example',storage=str(root/'private'),yt_dlp=str(tests/'fake-ytdlp.py'),ffmpeg='/usr/bin/ffmpeg',ffprobe='/usr/bin/ffprobe',setsid='/usr/bin/setsid',js_path=node)))
    env=os.environ.copy();env.update(MSVCR_CONFIG=str(config),MSVCR_TEST_ROOT=work,MSVC_TEST_ORIGIN='https://fixture.example',MSVC_TEST_MEDIA=str(fixture),MSVCR_TEST_PHP=php)
    for unit in ['wp-unit.php','backend-unit.php']:
        result=subprocess.run([php,str(tests/unit)],env=env,capture_output=True,text=True)
        print(result.stdout,end='',flush=True)
        if result.returncode: print(result.stderr);raise SystemExit(result.returncode)
    subprocess.run(['python3',str(tests/'startup-unit.py')],env=env,check=True)
    services=[]
    with (root/'server.log').open('w') as log:
        try:
            worker=subprocess.Popen([php,str(tests.parent/'backend/worker.php')],env=env,stdout=log,stderr=log);services.append(worker)
            env['MSVCR_TEST_WORKER_PID']=str(worker.pid)
            for port,router in [(8877,'wp-router.php'),(8878,'backend-router.php')]:
                services.append(subprocess.Popen([php,'-S',f'127.0.0.1:{port}',str(tests/router)],env=env,stdout=log,stderr=log))
            time.sleep(.5)
            if any(p.poll() is not None for p in services): raise RuntimeError('A test service did not start.')
            result=subprocess.run([node,str(tests/'ui.mjs')],env=env,capture_output=True,text=True,timeout=120)
            print(result.stdout,end='',flush=True)
            if result.returncode: print(result.stderr);print((root/'server.log').read_text());raise SystemExit(result.returncode)
        finally:
            for p in services:
                if p.poll() is None:p.terminate()
            for p in services:p.wait(timeout=10)
print('Local checks finished. Docker image, Render deployment, live YouTube and real WordPress deployment were not tested.')
