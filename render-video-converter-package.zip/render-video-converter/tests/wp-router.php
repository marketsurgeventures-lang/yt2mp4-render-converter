<?php
if (PHP_SAPI !== 'cli-server') { http_response_code(404); exit; }
require __DIR__.'/wp-bootstrap.php';
$path=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH);
if ($path==='/') { header('Content-Type: text/html'); echo '<!doctype html><html><body>'.MSVCR\Plugin::shortcode().'</body></html>'; exit; }
if (!preg_match('~^/wp-json/msvcr/v1/(session|analyze|convert)$~D',$path,$m)||$_SERVER['REQUEST_METHOD']!=='POST') { http_response_code(404); exit; }
$headers=[]; foreach (getallheaders() as $key=>$value) { $headers[strtolower($key)]=$value; }
$q=new MSVC_Test_Request(json_decode(file_get_contents('php://input'),true)?:[],$headers);
$allowed=$m[1]==='session'?MSVCR\Plugin::sameOrigin($q):MSVCR\Plugin::authorize($q);
$r=is_wp_error($allowed)?$allowed:MSVCR\Plugin::{$m[1]}($q);
header('Content-Type: application/json');
if (is_wp_error($r)) { http_response_code($r->data['status']??400); echo json_encode(['code'=>$r->code,'message'=>$r->message]); }
else { http_response_code($r->status); echo json_encode($r->data); }
