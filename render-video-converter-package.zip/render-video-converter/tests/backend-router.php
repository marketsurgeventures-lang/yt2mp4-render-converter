<?php
if (PHP_SAPI!=='cli-server') { http_response_code(404); exit; }
require dirname(__DIR__).'/backend/public/index.php';
