/** Real queue daemon + HTTP/browser controller + FFmpeg; only source extraction is a fixture. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
import {execFileSync,spawn} from 'node:child_process';
import {once} from 'node:events';
const require=createRequire(import.meta.url);
const {JSDOM}=require(process.env.MSVC_JSDOM||'jsdom');
const wp='http://127.0.0.1:8877',backend='http://127.0.0.1:8878',origin='https://fixture.example',remote='https://converter.fixture.example';
const html=await(await fetch(wp)).text();
const source=fs.readFileSync(new URL('../wordpress/render-video-converter/assets/tool.js',import.meta.url),'utf8');
let cookie='',count=0,lastTicket='',analysisOwner='',analysisId='',restarted;
const pass=(name)=>{count++;console.log(`PASS: ${name}`);};
const translate=(value)=>{const u=new URL(value);if(u.hostname==='fixture.example')return wp+u.pathname+u.search;if(u.hostname==='converter.fixture.example')return backend+u.pathname+u.search;throw new Error('Unexpected fixture host');};
const mockFetch=async(url,options={})=>{
 const h=new Headers(options.headers||{});h.set('Origin',origin);
 if(new URL(url).hostname==='fixture.example'&&cookie)h.set('Cookie',cookie);
 if(String(url).endsWith('/submit'))lastTicket=h.get('Authorization');
 const r=await fetch(translate(url),{...options,headers:h});
 const set=r.headers.get('set-cookie');if(set)cookie=set.split(';')[0];
 if(String(url).endsWith('/analyze')){const data=await r.clone().json();analysisId=data.job;if(data.ticket)analysisOwner=JSON.parse(Buffer.from(data.ticket.split('.')[0],'base64url').toString()).owner;}
 return r;
};
const makeWindow=(saved)=>{
 const dom=new JSDOM(html,{url:origin,runScripts:'outside-only',pretendToBeVisual:true});
 dom.window.fetch=mockFetch;dom.window.AbortController=AbortController;
 if(saved)dom.window.localStorage.setItem('msvcr:https://fixture.example/wp-json/msvcr/v1/:mp4',JSON.stringify(saved));
 dom.window.eval(source);dom.window.document.dispatchEvent(new dom.window.Event('DOMContentLoaded'));return dom;
};
const wait=async(fn,label)=>{const end=Date.now()+20000;while(Date.now()<end){if(await fn())return;await new Promise(r=>setTimeout(r,100));}throw new Error(label);};
const ticket=(body)=>{const p={id:crypto.randomBytes(16).toString('hex'),owner:crypto.randomBytes(32).toString('hex'),origin,exp:Math.floor(Date.now()/1000)+120,...body};const v=Buffer.from(JSON.stringify(p)).toString('base64url');return v+'.'+crypto.createHmac('sha256','b'.repeat(64)).update(v).digest('hex');};
const admit=async(body)=>{const r=await fetch(backend+'/submit',{method:'POST',headers:{Origin:origin,Authorization:'Bearer '+ticket(body)},body:'{}'});assert.equal(r.status,202,await r.clone().text());return r.json();};
const status=async(job)=>{const r=await fetch(backend+'/status?id='+job.job,{headers:{Origin:origin,Authorization:'Bearer '+job.access_token}});assert.equal(r.status,200);return r.json();};
const done=async(job)=>{let data;await wait(async()=>{data=await status(job);return ['complete','failed'].includes(data.state);},'Job completion');return data;};
const dom=makeWindow();const w=dom.window,q=(s)=>w.document.querySelector(s);
try{
 await wait(()=>!q('.msvc-start').disabled,'Initialization');pass('Render shortcode initializes without a conversion engine on WordPress');
 assert.equal(html.includes('b'.repeat(64)),false);pass('Shared secret absent from frontend HTML');
 q('[name="video_url"]').value='https://youtu.be/AAAAAAAAAAA';q('[name="authorized"]').checked=true;
 q('.msvc-form').dispatchEvent(new w.Event('submit',{cancelable:true,bubbles:true}));
 await wait(()=>!q('.msvc-result').hidden&&!q('.msvc-convert').disabled,'Analyze');
 assert.deepEqual(Array.from(q('.msvc-quality').options).map(o=>o.value),['360','180']);pass('Source choices pass through the queue and respect the free pilot quality cap');
 assert.equal(q('.msvc-video-title script'),null);pass('Source title renders as safe text');
 for(const format of ['mp4','mp3']){
  q(`[data-format="${format}"]`).click();q('.msvc-convert').click();await wait(()=>!q('.msvc-download').hidden&&!q('.msvc-convert').disabled,format);
  const url=q('.msvc-download-link').href;assert.equal(new URL(url).origin,remote);
  const r=await fetch(translate(url));assert.equal(r.status,200);assert.match(r.headers.get('content-disposition'),/attachment/);
  const file=path.join(os.tmpdir(),`msvcr-real-test-${process.pid}.${format}`);fs.writeFileSync(file,Buffer.from(await r.arrayBuffer()));
  const media=JSON.parse(execFileSync('/usr/bin/ffprobe',['-v','error','-show_entries','stream=codec_type,codec_name','-of','json',file],{encoding:'utf8'}));fs.unlinkSync(file);
  assert.ok(media.streams.some(s=>s.codec_name===(format==='mp4'?'h264':'mp3')));pass(`${format.toUpperCase()} converts and downloads with real FFmpeg and a signed link`);
  const partial=await fetch(translate(url),{headers:{Range:'bytes=0-15'}});assert.equal(partial.status,206);assert.equal((await partial.arrayBuffer()).byteLength,16);pass(`${format.toUpperCase()} download supports resumable byte ranges`);
  const bad=new URL(url);bad.searchParams.set('sig','f'.repeat(64));assert.equal((await fetch(translate(bad))).status,403);pass(`${format.toUpperCase()} forged download signature rejected`);
  const replay=await fetch(backend+'/submit',{method:'POST',headers:{Origin:origin,Authorization:lastTicket},body:'{}'});assert.equal(replay.status,409);pass(`${format.toUpperCase()} processing ticket replay rejected`);
 }
 assert.equal((await fetch(backend+'/submit',{method:'POST',headers:{Origin:origin,Authorization:'Bearer forged'}})).status,403);pass('Forged processing authorization rejected');
 assert.equal((await fetch(backend+'/status?id='+analysisId,{headers:{Origin:origin,Authorization:'Bearer '+'f'.repeat(64)}})).status,403);pass('Another visitor cannot read status without the request capability');
 const cross=await fetch(backend+'/submit',{method:'POST',headers:{Origin:origin,Authorization:'Bearer '+ticket({kind:'convert',analysis:analysisId,format:'mp3',quality:192})}});assert.equal(cross.status,403);pass('Another visitor cannot convert the owned analysis');
 const quality=await fetch(backend+'/submit',{method:'POST',headers:{Origin:origin,Authorization:'Bearer '+ticket({kind:'convert',analysis:analysisId,owner:analysisOwner,format:'mp4',quality:480})}});assert.equal(quality.status,400);pass('Unavailable source quality rejected');
 assert.equal((await fetch(backend+'/submit',{method:'OPTIONS',headers:{Origin:'https://evil.example'}})).status,403);pass('Cross-origin preflight rejected');
 const preflight=await fetch(backend+'/submit',{method:'OPTIONS',headers:{Origin:origin}});assert.equal(preflight.status,204);assert.equal(preflight.headers.get('access-control-allow-origin'),origin);pass('Configured WordPress origin allowed');
 const health=await fetch(backend+'/health',{headers:{Authorization:'Bearer '+'b'.repeat(64)}});assert.equal(health.status,200);assert.equal((await health.json()).ok,true);pass('Health verifies the actual running daemon and local engine');
 assert.equal((await fetch(backend+'/health')).status,403);pass('Administrative diagnostics require the shared secret');
 const probe=await fetch(backend+'/healthz');assert.equal(probe.status,200);assert.deepEqual(await probe.json(),{ok:true,configured:true});pass('Public Render readiness works without administrative credentials');
 const cfg=JSON.parse(fs.readFileSync(process.env.MSVCR_CONFIG,'utf8'));const pausePath=path.join(cfg.storage,'paused');fs.writeFileSync(pausePath,'paused');
 try { assert.equal((await fetch(backend+'/healthz')).status,200);pass('Operator pause keeps the container healthy without triggering restart'); }
 finally { fs.unlinkSync(pausePath); }

 // A long fixture occupies the daemon while a second request waits and cancels.
 const slow=await admit({kind:'analyze',url:'SLOWVIDEO01'});
 await wait(async()=> (await status(slow)).state==='running','Slow job starts');
 const queued=await admit({kind:'analyze',url:'BBBBBBBBBBB'});const view=await status(queued);
 assert.equal(view.state,'queued');assert.ok(view.position>=2);pass('Burst requests wait in FIFO order behind the single worker');
 await fetch(backend+'/cancel',{method:'POST',headers:{Origin:origin,Authorization:'Bearer '+queued.access_token},body:JSON.stringify({id:queued.job})});assert.equal((await status(queued)).state,'failed');pass('Queued request cancellation is immediate');
 await fetch(backend+'/cancel',{method:'POST',headers:{Origin:origin,Authorization:'Bearer '+slow.access_token},body:JSON.stringify({id:slow.job})});assert.equal((await done(slow)).state,'failed');pass('Running request cancellation stops its source subprocess');
 const detached=await admit({kind:'analyze',url:'CCCCCCCCCCC'});await new Promise(r=>setTimeout(r,1400));assert.equal((await done(detached)).state,'complete');pass('Accepted processing continues without an open progress connection');
 const long=await admit({kind:'analyze',url:'LONGVIDEO01'});assert.equal((await done(long)).state,'failed');pass('Duration limit is enforced by the actual engine');
 // Restart the real CLI daemon and resume a conversion from a fresh browser controller.
 process.kill(Number(process.env.MSVCR_TEST_WORKER_PID),'SIGTERM');await new Promise(r=>setTimeout(r,700));
 const persistent=await admit({kind:'convert',analysis:analysisId,owner:analysisOwner,format:'mp3',quality:128});
 assert.equal((await status(persistent)).state,'queued');pass('Pending job remains available with the daemon stopped');
 restarted=spawn(process.env.MSVCR_TEST_PHP,[new URL('../backend/worker.php',import.meta.url).pathname],{env:process.env,stdio:'ignore'});
 const saved={...persistent,worker:remote,kind:'convert',saved:Date.now()};const resumed=makeWindow(saved);
 await wait(()=>!resumed.window.document.querySelector('.msvc-download').hidden,'Resume after refresh');resumed.window.close();pass('Daemon restart and browser refresh recover the accepted conversion');
 q('[name="video_url"]').value='https://evil.example';q('[name="video_url"]').dispatchEvent(new w.Event('input'));assert.equal(q('.msvc-result').hidden,true);pass('Changed URL invalidates the previous analysis');
 console.log(`TOTAL: ${count} passed`);
}finally{
 dom.window.close();
 if(restarted&&restarted.exitCode===null){restarted.kill('SIGTERM');await once(restarted,'exit');}
}
