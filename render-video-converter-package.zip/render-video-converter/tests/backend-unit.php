<?php
if (PHP_SAPI!=='cli') { exit; }
require dirname(__DIR__).'/backend/includes/render.php';
$c=\MSVCR\config();
if (($argv[1]??'')==='race') {
    $n=(int)$argv[2]; $p=['id'=>bin2hex(random_bytes(16)),'kind'=>'convert','owner'=>hash('sha256','owner-'.$n),'analysis'=>md5('analysis-'.$n),'format'=>'mp3','quality'=>192];
    try { (new \MSVCR\Queue($c))->submit($p); echo 'accepted'; } catch (\MSVCR\RequestError $e) { echo 'rejected'; } exit;
}
$count=0;
function check($value,$name) { global $count; if (!$value) { throw new RuntimeException('FAIL: '.$name); } $count++; echo 'PASS: '.$name."\n"; }
function rejected(callable $fn,string $name) { try { $fn(); } catch (Throwable $e) { check(true,$name); return; } check(false,$name); }
$c['storage'].='-unit'; $c['daily']=3;
$q=new \MSVCR\Queue($c); $q->beat();
check(\MSVCR\config()['daily']===20,'Default backend limits the free pilot to 20 conversions/day');
check(\MSVC\Input::video('https://youtu.be/AAAAAAAAAAA')['url']==='https://www.youtube.com/watch?v=AAAAAAAAAAA','YouTube URL canonicalized');
rejected(fn()=>\MSVC\Input::video('https://youtube.com.evil.test/watch?v=AAAAAAAAAAA'),'Spoofed source host rejected');
$p=['id'=>bin2hex(random_bytes(16)),'kind'=>'analyze','owner'=>str_repeat('a',64),'origin'=>$c['origin'],'url'=>'AAAAAAAAAAA','exp'=>time()+120];
$encode=function($p) use($c) { $v=rtrim(strtr(base64_encode(json_encode($p)),'+/','-_'),'=');return $v.'.'.hash_hmac('sha256',$v,$c['secret']); };
check(\MSVCR\Ticket::decode($encode($p),$c)['url']==='https://www.youtube.com/watch?v=AAAAAAAAAAA','Signed ticket binds canonical source');
rejected(fn()=>\MSVCR\Ticket::decode($encode($p).'a',$c),'Tampered processing ticket rejected');
$expired=$p;$expired['exp']=time()-1;
rejected(fn()=>\MSVCR\Ticket::decode($encode($expired),$c),'Expired processing ticket rejected');
$other=$p;$other['origin']='https://evil.example';
rejected(fn()=>\MSVCR\Ticket::decode($encode($other),$c),'Wrong ticket origin rejected');
$admitted=$q->submit($p);check($q->store->read($p['id'])['state']==='queued','Accepted request persists in private queue');
rejected(fn()=>$q->submit($p),'Processing authorization cannot be replayed');
rejected(fn()=>$q->authorized($p['id'],str_repeat('f',64)),'Unknown job access token rejected');
check($q->publicJob($q->authorized($p['id'],$admitted['access_token']))['position']===1,'FIFO queue position exposed without private fields');
$public=json_encode($q->publicJob($q->authorized($p['id'],$admitted['access_token'])));
check(!str_contains($public,$c['secret'])&&!str_contains($public,'access_hash')&&!str_contains($public,'config'),'Public job status excludes internal configuration');
$q->cancel($p['id'],$admitted['access_token']);
check($q->store->read($p['id'])['state']==='failed','Queued cancellation is immediate');
$second=$p;$second['id']=bin2hex(random_bytes(16));$second['owner']=str_repeat('c',64);$q->submit($second);
$running=$q->next();check($running['id']===$second['id']&&$running['state']==='running','Worker claims oldest valid queued request');
$q->recover();check($q->store->read($second['id'])['state']==='failed','Restart marks interrupted running jobs failed');
$third=$p;$third['id']=bin2hex(random_bytes(16));$third['owner']=str_repeat('d',64);$q->submit($third);
$reloaded=new \MSVCR\Queue($c);check($reloaded->store->read($third['id'])['state']==='queued','Pending queue survives a new server instance');
$j=$q->store->read($third['id']);$j['created']=time()-1801;$q->store->write($j);$q->next();
check($q->store->read($third['id'])['state']==='failed','Queue wait timeout is enforced');
file_put_contents($q->store->root.'/paused','paused');$paused=$p;$paused['id']=bin2hex(random_bytes(16));
rejected(fn()=>$q->submit($paused),'Operator pause rejects new admission');unlink($q->store->root.'/paused');
$lock=$q->store->lock('daemon',true);check($q->store->lock('daemon',true)===false,'Only one worker daemon can own the queue');flock($lock,LOCK_UN);fclose($lock);
// Concurrent independent PHP requests share the authoritative daily quota.
$race=$c;$race['storage']=$c['storage'].'-race';$raceQ=new \MSVCR\Queue($race);$raceQ->beat();
$info=['video_id'=>'AAAAAAAAAAA','title'=>'fixture','duration'=>2,'qualities'=>[180,360,720],'has_audio'=>true];
for($i=0;$i<8;$i++) { $raceQ->store->write(['id'=>md5('analysis-'.$i),'kind'=>'analyze','state'=>'complete','owner'=>hash('sha256','owner-'.$i),'created'=>time(),'expires'=>time()+3600,'result'=>$info,'url'=>'https://www.youtube.com/watch?v=AAAAAAAAAAA']); }
$raceFile=$c['storage'].'-race-config.json';file_put_contents($raceFile,json_encode($race));
$children=[];
for($i=0;$i<8;$i++) { $env=getenv();$env['MSVCR_CONFIG']=$raceFile;$proc=proc_open([getenv('MSVCR_TEST_PHP')?:PHP_BINARY,__FILE__,'race',(string)$i],[0=>['file','/dev/null','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes,null,$env);$children[]=[$proc,$pipes]; }
$accepted=0;
foreach($children as [$proc,$pipes]) { $out=stream_get_contents($pipes[1]);$err=stream_get_contents($pipes[2]);foreach($pipes as $pipe) { fclose($pipe); }check(proc_close($proc)===0,'Concurrent admission process completes');if(trim($out)==='accepted')$accepted++; }
check($accepted===3,'Concurrent requests cannot exceed the configured daily cap');
$counter=json_decode(file_get_contents($raceQ->store->root.'/admission.json'),true);check($counter['convert']===3,'Daily quota persists independently of job cleanup');
echo 'TOTAL: '.$count." passed\n";
