<?php
if (PHP_SAPI!=='cli') { exit; }
ob_start();
require __DIR__.'/wp-bootstrap.php';
require dirname(__DIR__).'/backend/includes/render.php';
$count=0; function check($ok,$name) { global $count; if (!$ok) { throw new RuntimeException('FAIL: '.$name); } $count++; echo 'PASS: '.$name."\n"; }
$session=MSVCR\Plugin::session(new MSVC_Test_Request()); $cookies=$_COOKIE;
$headers=['origin'=>home_url(),'x-msvc-token'=>$session->data['token']];
check($session->data['available'],'Configured Render companion initializes');
check(MSVCR\Plugin::authorize(new MSVC_Test_Request([],$headers))===true,'Visitor-bound processing authorization');
check(is_wp_error(MSVCR\Plugin::authorize(new MSVC_Test_Request())), 'Forged/missing token rejected');
check(is_wp_error(MSVCR\Plugin::analyze(new MSVC_Test_Request(['url'=>'AAAAAAAAAAA']))),'Consent checked server-side');
check(is_wp_error(MSVCR\Plugin::analyze(new MSVC_Test_Request(['url'=>'https://127.0.0.1/','authorized'=>true]))),'Non-YouTube source rejected');
$r=MSVCR\Plugin::analyze(new MSVC_Test_Request(['url'=>'AAAAAAAAAAA','authorized'=>true]));
check($r instanceof WP_REST_Response&&$r->status===202,'Analysis ticket issued without a local conversion engine');
$p=MSVCR\Ticket::decode($r->data['ticket'],array_merge($c,['origin'=>home_url()]));
check($p['url']==='https://www.youtube.com/watch?v=AAAAAAAAAAA'&&$p['kind']==='analyze','Render verifies the WordPress signature and canonical source');
check(!str_contains(json_encode($r->data),$c['secret']),'Shared secret withheld from public response');
try { MSVCR\Ticket::decode($r->data['ticket'].'a',array_merge($c,['origin'=>home_url()])); check(false,'Tamper rejected'); } catch (Throwable $e) { check(true,'Tampered ticket rejected'); }
$id=$r->data['job'];
$convert=MSVCR\Plugin::convert(new MSVC_Test_Request(['analysis'=>$id,'format'=>'mp3','quality'=>192,'authorized'=>true]));
check($convert instanceof WP_REST_Response,'Owned conversion ticket issued');
$_COOKIE=[]; MSVCR\Plugin::session(new MSVC_Test_Request());
check(is_wp_error(MSVCR\Plugin::convert(new MSVC_Test_Request(['analysis'=>$id,'format'=>'mp3','quality'=>192,'authorized'=>true]))),'Another visitor cannot use analysis'); $_COOKIE=$cookies;
check(is_wp_error(MSVCR\Plugin::convert(new MSVC_Test_Request(['analysis'=>$id,'format'=>'mp4','quality'=>2160,'authorized'=>true]))),'Unsupported high quality rejected');
$saved=MSVCR\Plugin::sanitizeSettings(['backend_url'=>'https://converter.fixture.example','enabled'=>1,'secret'=>'','daily'=>1,'rate'=>30]);
check($saved['secret']===$c['secret'],'Blank settings password keeps saved secret');
$GLOBALS['msvc_test_options']['msvcr_settings']=$saved;
$GLOBALS['msvc_test_options']['msvcr_report']=['ok'=>true,'fingerprint'=>hash('sha256',json_encode($saved))];
set_transient('msvcr_day_convert_'.gmdate('Ymd'),1,172800);
check(is_wp_error(MSVCR\Plugin::convert(new MSVC_Test_Request(['analysis'=>$id,'format'=>'mp3','quality'=>192,'authorized'=>true]))),'Whole-site daily conversion cap enforced');
check(!str_contains(MSVCR\Plugin::shortcode(),$c['secret']),'Shared secret withheld from shortcode HTML');
echo 'TOTAL: '.$count." passed\n";
ob_end_flush();
