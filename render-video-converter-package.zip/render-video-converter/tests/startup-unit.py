#!/usr/bin/env python3
"""Exercise real runtime configuration, safe setup mode and port validation."""
import json
import os
from pathlib import Path
import stat
import subprocess
import tempfile

base=Path(__file__).resolve().parent.parent
php=os.environ['MSVCR_TEST_PHP']
count=0
def check(value, name):
    global count
    if not value: raise AssertionError(name)
    count+=1
    print('PASS: '+name,flush=True)

with tempfile.TemporaryDirectory(prefix='msvcr-startup-') as work:
    root=Path(work)
    path=root/'config/config.json'
    env=os.environ.copy()
    for key in ['MSVCR_BACKEND_URL','MSVCR_DAILY','MSVCR_MAX_MINUTES','MSVCR_MAX_HEIGHT','MSVCR_MAX_MB']:
        env.pop(key,None)
    env.update(MSVCR_CONFIG=str(path),MSVCR_STORAGE=str(root/'private'),MSVCR_ENABLED='0')
    def configure(): return subprocess.run([php,str(base/'deploy/configure.php')],env=env,capture_output=True,text=True)
    result=configure()
    check(result.returncode==10 and not path.exists(),'Disabled setup mode requires no secret and starts no conversion queue')
    env.update(MSVCR_ENABLED='1',WORDPRESS_ORIGIN='https://fixture.example',RENDER_EXTERNAL_URL='https://converter.fixture.example',MSVCR_SHARED_SECRET='b'*64)
    result=configure()
    check(result.returncode==0,'Valid runtime settings create the private configuration')
    config=json.loads(path.read_text())
    check(config['backend_url']==env['RENDER_EXTERNAL_URL'],'Download origin uses Render external URL rather than a request Host header')
    check(config['daily']==20 and config['max_minutes']==2 and config['max_mb']==20 and config['max_height']==360,'Free pilot defaults are applied before the daemon starts')
    check(stat.S_IMODE(path.stat().st_mode)==0o600,'Generated shared secret is stored in an owner-only file')
    check(env['MSVCR_SHARED_SECRET'] not in result.stdout+result.stderr,'Startup logs withhold the shared secret')
    env['MSVCR_MAX_MINUTES']='99';result=configure()
    check(result.returncode==1 and not path.exists(),'Out-of-range settings fail startup rather than relaxing the resource cap')
    env.pop('MSVCR_MAX_MINUTES');env['MSVCR_SHARED_SECRET']='invalid';result=configure()
    check(result.returncode==1 and not path.exists(),'An invalid shared secret cannot enable processing')
    env['PORT']='10000; echo unsafe'
    result=subprocess.run(['python3',str(base/'deploy/run.py')],env=env,capture_output=True,text=True)
    check(result.returncode!=0 and 'PORT must' in result.stderr,'Invalid port input is rejected before any service process starts')
print(f'TOTAL: {count} passed',flush=True)
